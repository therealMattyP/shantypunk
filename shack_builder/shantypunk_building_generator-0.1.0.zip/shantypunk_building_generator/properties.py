import bpy
from bpy.props import BoolProperty, FloatProperty, IntProperty, PointerProperty
from bpy.types import PropertyGroup


class SPBuildingSettings(PropertyGroup):
    seed: IntProperty(name="Seed", default=41, min=0, max=999999)
    density: FloatProperty(
        name="Candidate Density", default=1.0, min=0.0, max=1.0, subtype='FACTOR')
    residential_weight: FloatProperty(
        name="Residential", default=0.65, min=0.0, max=1.0, subtype='FACTOR')
    storefront_weight: FloatProperty(
        name="Storefront", default=0.22, min=0.0, max=1.0, subtype='FACTOR')
    utility_weight: FloatProperty(
        name="Utility / Storage", default=0.13, min=0.0, max=1.0, subtype='FACTOR')
    side_margin: FloatProperty(
        name="Side Margin", default=0.16, min=0.0, max=1.5, unit='LENGTH')
    rear_margin: FloatProperty(
        name="Rear Margin", default=0.12, min=0.0, max=1.5, unit='LENGTH')
    access_apron_depth: FloatProperty(
        name="Minimum Access Apron", default=0.75, min=0.3, max=3.0, unit='LENGTH')
    minimum_depth: FloatProperty(
        name="Minimum Cell Depth", default=0.85, min=0.6, max=6.0, unit='LENGTH')
    minimum_frontage: FloatProperty(
        name="Minimum Frontage", default=1.8, min=1.2, max=8.0, unit='LENGTH')
    height_factor: FloatProperty(
        name="Height Factor", default=0.88, min=0.55, max=1.0, subtype='FACTOR')
    show_planning_volumes: BoolProperty(
        name="Show Aprons and Candidate Bounds", default=False)


classes = (SPBuildingSettings,)

SETTING_FIELDS = (
    "seed", "density", "residential_weight", "storefront_weight",
    "utility_weight", "side_margin", "rear_margin", "access_apron_depth",
    "minimum_depth", "minimum_frontage", "height_factor",
    "show_planning_volumes",
)


def copy_settings(source, destination):
    for name in SETTING_FIELDS:
        setattr(destination, name, getattr(source, name))


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.sp_building_settings = PointerProperty(type=SPBuildingSettings)
    bpy.types.Object.sp_building_settings = PointerProperty(type=SPBuildingSettings)


def unregister():
    del bpy.types.Object.sp_building_settings
    del bpy.types.Scene.sp_building_settings
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
