import bpy
from bpy.types import Operator, Panel

from . import contracts, generator


def selected_host(context):
    return contracts.host_controller_from_object(context.active_object)


def selected_building(context):
    direct = contracts.building_controller_from_object(context.active_object)
    if direct:
        return direct
    return contracts.building_for_host(selected_host(context))


def report_result(operator, manifest, report, verb):
    errors = report["summary"]["ERROR"]
    count = len(manifest.get("cells", []))
    if errors:
        operator.report({'WARNING'}, "%s %d cells with %d validation errors" % (verb, count, errors))
    else:
        operator.report({'INFO'}, "%s %d validated building cells" % (verb, count))


class SPBUILD_OT_generate(Operator):
    bl_idname = "spbuild.generate"
    bl_label = "Generate Buildings"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        host = selected_host(context)
        return host is not None and contracts.circulation_for_host(host) is not None

    def execute(self, context):
        try:
            manifest, report, _controller = generator.generate(
                context, host_controller=selected_host(context))
        except ValueError as error:
            self.report({'ERROR'}, str(error))
            return {'CANCELLED'}
        report_result(self, manifest, report, "Generated")
        return {'FINISHED'}


class SPBUILD_OT_update(Operator):
    bl_idname = "spbuild.update"
    bl_label = "Update Buildings"
    bl_description = "Refit proxy buildings from current host and circulation contracts"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return selected_building(context) is not None

    def execute(self, context):
        try:
            manifest, report, _controller = generator.generate(
                context, controller=selected_building(context))
        except ValueError as error:
            self.report({'ERROR'}, str(error))
            return {'CANCELLED'}
        report_result(self, manifest, report, "Updated")
        return {'FINISHED'}


class SPBUILD_OT_validate(Operator):
    bl_idname = "spbuild.validate"
    bl_label = "Validate Buildings"

    @classmethod
    def poll(cls, context):
        return selected_building(context) is not None

    def execute(self, context):
        report = generator.validate_controller(selected_building(context))
        if report is None:
            self.report({'ERROR'}, "Buildings have no readable source contract or manifest")
            return {'CANCELLED'}
        self.report(
            {'INFO' if not report['summary']['ERROR'] else 'WARNING'},
            "%d errors, %d warnings" % (
                report['summary']['ERROR'], report['summary']['WARNING']))
        return {'FINISHED'}


class SPBUILD_OT_delete(Operator):
    bl_idname = "spbuild.delete"
    bl_label = "Delete Buildings"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return selected_building(context) is not None

    def execute(self, context):
        generator.delete_buildings(selected_building(context))
        self.report({'INFO'}, "Deleted buildings; host and circulation were preserved")
        return {'FINISHED'}


def draw_settings(layout, settings):
    row = layout.row(align=True)
    row.prop(settings, "seed")
    row.prop(settings, "density")
    box = layout.box()
    box.label(text="Use Mix")
    box.prop(settings, "residential_weight")
    box.prop(settings, "storefront_weight")
    box.prop(settings, "utility_weight")
    box = layout.box()
    box.label(text="Cell Fitting")
    row = box.row(align=True)
    row.prop(settings, "minimum_frontage")
    row.prop(settings, "minimum_depth")
    row = box.row(align=True)
    row.prop(settings, "side_margin")
    row.prop(settings, "rear_margin")
    box.prop(settings, "access_apron_depth")
    box.prop(settings, "height_factor")
    box = layout.box()
    box.label(text="Planning Display")
    box.prop(settings, "show_planning_volumes")


class SPBUILD_PT_panel(Panel):
    bl_label = "Building Generator"
    bl_idname = "SPBUILD_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Shantypunk"

    def draw(self, context):
        layout = self.layout
        host = selected_host(context)
        buildings = selected_building(context)
        if not host:
            layout.label(text="Select a Host Controller", icon='INFO')
            layout.label(text="or any generated child")
            return
        circulation = contracts.circulation_for_host(host)
        layout.label(text="Host: %s" % host.get("SP_INSTANCE_ID", host.name), icon='EMPTY_AXIS')
        if not circulation:
            layout.label(text="Generate circulation first", icon='ERROR')
            return
        layout.label(
            text="Circulation: %s" % circulation.get("SP_INSTANCE_ID", circulation.name),
            icon='OUTLINER_OB_CURVE')
        if buildings:
            layout.label(
                text="Buildings: %s" % buildings.get("SP_INSTANCE_ID", buildings.name),
                icon='OUTLINER_OB_MESH')
            draw_settings(layout, buildings.sp_building_settings)
            layout.operator("spbuild.update", icon='FILE_REFRESH')
            row = layout.row(align=True)
            row.operator("spbuild.validate", icon='CHECKMARK')
            row.operator("spbuild.delete", icon='TRASH')
        else:
            layout.label(text="New Building Defaults", icon='HOME')
            draw_settings(layout, context.scene.sp_building_settings)
            layout.operator("spbuild.generate", icon='HOME')


classes = (
    SPBUILD_OT_generate,
    SPBUILD_OT_update,
    SPBUILD_OT_validate,
    SPBUILD_OT_delete,
    SPBUILD_PT_panel,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

