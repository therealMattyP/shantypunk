"""Read-only adapters for Host and Circulation public custom-property contracts."""

import hashlib
import json

import bpy
from mathutils import Vector


def controller_from_object(obj, role):
    while obj:
        if obj.get("SP_ROLE") == role:
            return obj
        obj = obj.parent
    return None


def building_controller_from_object(obj):
    return controller_from_object(obj, "BUILDING_CONTROLLER")


def circulation_controller_from_object(obj):
    circulation = controller_from_object(obj, "CIRCULATION_CONTROLLER")
    if circulation:
        return circulation
    host = host_controller_from_object(obj)
    if host:
        return circulation_for_host(host)
    return None


def host_controller_from_object(obj):
    building = controller_from_object(obj, "BUILDING_CONTROLLER")
    if building:
        obj = building.parent
    circulation = controller_from_object(obj, "CIRCULATION_CONTROLLER")
    if circulation:
        obj = circulation.parent
    return controller_from_object(obj, "HOST_CONTROLLER")


def child_controller(host, role):
    if not host:
        return None
    return next((child for child in host.children if child.get("SP_ROLE") == role), None)


def circulation_for_host(host):
    return child_controller(host, "CIRCULATION_CONTROLLER")


def building_for_host(host):
    return child_controller(host, "BUILDING_CONTROLLER")


def descendants(controller):
    found = []
    pending = list(controller.children) if controller else []
    while pending:
        obj = pending.pop()
        found.append(obj)
        pending.extend(obj.children)
    return found


def host_sockets(host, socket_type="CELL_ATTACH"):
    return sorted([
        obj for obj in descendants(host)
        if obj.get("SP_ROLE") == "SOCKET"
        and obj.get("SP_SOCKET_TYPE") == socket_type
    ], key=lambda obj: (int(obj.get("SP_LEVEL", 0)), obj.get("SP_ID", obj.name)))


def circulation_nodes(circulation, node_type=None):
    nodes = [obj for obj in descendants(circulation)
             if obj.get("SP_ROLE") == "CIRCULATION_NODE"]
    if node_type:
        nodes = [obj for obj in nodes if obj.get("SP_NODE_TYPE") == node_type]
    return sorted(nodes, key=lambda obj: obj.get("SP_ID", obj.name))


def read_manifest(controller):
    if not controller:
        return {}
    text = bpy.data.texts.get(controller.get("SP_MANIFEST_TEXT", ""))
    if not text:
        return {}
    try:
        return json.loads(text.as_string())
    except (TypeError, ValueError, json.JSONDecodeError):
        return {}


def _vector(value, default=(0.0, 0.0, 0.0)):
    try:
        return Vector(tuple(float(item) for item in value[:3]))
    except (TypeError, ValueError, AttributeError):
        return Vector(default)


def _record_vector(record, *keys, default=(0.0, 0.0, 0.0)):
    for key in keys:
        if key in record:
            return _vector(record[key], default)
    return Vector(default)


def _access_reachability(manifest):
    nodes = {node.get("id"): node for node in manifest.get("nodes", []) if node.get("id")}
    entries = {node_id for node_id, node in nodes.items() if node.get("type") == "GROUND_ENTRY"}
    reachable = set(entries)
    changed = True
    while changed:
        changed = False
        for edge in manifest.get("edges", []):
            if edge.get("from") in reachable and edge.get("to") not in reachable:
                reachable.add(edge.get("to"))
                changed = True
    return reachable


def access_contracts(host, circulation):
    """Return normalized host-local access contracts, supporting v0.1 and v0.2."""
    manifest = read_manifest(circulation)
    reachable = _access_reachability(manifest)
    normalized = []
    records = manifest.get("access_contracts", [])
    if records:
        for record in records:
            source_socket = record.get("source_socket", record.get("source_socket_id", ""))
            node_id = record.get("node_id", record.get("access_node", ""))
            outward = _record_vector(
                record, "entrance_direction", "outward_direction", default=(0.0, -1.0, 0.0))
            depth = _record_vector(record, "depth_direction", "build_side", default=-outward)
            if depth.length_squared < 1e-8:
                depth = -outward
            normalized.append({
                "source_socket": source_socket,
                "node_id": node_id,
                "location": _record_vector(record, "location"),
                "outward_direction": outward.normalized() if outward.length else Vector((0, -1, 0)),
                "depth_direction": depth.normalized() if depth.length else Vector((0, 1, 0)),
                "frontage_width": float(record.get("frontage_width", 0.0)),
                "apron_depth": float(record.get("apron_depth", 0.0)),
                "reachable": bool(record.get("reachable", not reachable or node_id in reachable)),
            })
        return normalized

    # v0.1 fallback: infer the frontage direction from access to the nearest
    # landing on the same level. The node and its source socket share a point.
    nodes = circulation_nodes(circulation)
    landings = [obj for obj in nodes if obj.get("SP_NODE_TYPE") == "LANDING"]
    for access in [obj for obj in nodes if obj.get("SP_NODE_TYPE") == "BUILDING_ACCESS"]:
        level = int(access.get("SP_LEVEL", 0))
        same_level = [obj for obj in landings if int(obj.get("SP_LEVEL", 0)) == level]
        if same_level:
            landing = min(same_level, key=lambda obj: (obj.location - access.location).length)
            outward = landing.location - access.location
        else:
            outward = Vector((0.0, -1.0, 0.0))
        outward.z = 0.0
        if outward.length < 1e-5:
            outward = Vector((0.0, -1.0, 0.0))
        outward.normalize()
        source_socket = access.get("SP_SOURCE_SOCKET", "")
        normalized.append({
            "source_socket": source_socket,
            "node_id": access.get("SP_ID", access.name),
            "location": access.location.copy(),
            "outward_direction": outward,
            "depth_direction": -outward,
            "frontage_width": 0.0,
            "apron_depth": 0.0,
            "reachable": not reachable or access.get("SP_ID") in reachable,
        })
    return normalized


def restrictions(circulation):
    """Return normalized host-local exclusion AABBs and their stable IDs."""
    manifest = read_manifest(circulation)
    result = []
    for key in ("exclusions", "opening_reservations"):
        for index, record in enumerate(manifest.get(key, [])):
            stable_id = record.get("id", "%s_%03d" % (key.upper(), index))
            minimum = _record_vector(record, "minimum", "min")
            maximum = _record_vector(record, "maximum", "max")
            if (maximum - minimum).length < 1e-6:
                center = _record_vector(record, "center", "location")
                dimensions = _record_vector(record, "dimensions", "size")
                minimum, maximum = center - dimensions * 0.5, center + dimensions * 0.5
            result.append({"id": stable_id, "minimum": minimum, "maximum": maximum, "kind": key})
    if result:
        return result

    # v0.1 semantic fallback. Segment bounds avoid the false endpoint extension
    # in the old cube-beam clearance display meshes.
    contracts = manifest.get("contracts", {})
    route_width = float(contracts.get("route_width", 1.1))
    headroom = float(contracts.get("headroom", 2.15))
    for index, segment in enumerate(manifest.get("segments", [])):
        start, end = _vector(segment.get("start")), _vector(segment.get("end"))
        horizontal = Vector((end.x - start.x, end.y - start.y, 0.0))
        if horizontal.length > 1e-6:
            perpendicular = Vector((-horizontal.y, horizontal.x, 0.0)).normalized()
            corners = [start + perpendicular * route_width * side * 0.5
                       for side in (-1.0, 1.0)]
            corners += [end + perpendicular * route_width * side * 0.5
                        for side in (-1.0, 1.0)]
        else:
            half = Vector((route_width * 0.5, route_width * 0.5, 0.0))
            corners = [start - half, start + half]
        minimum = Vector((min(point.x for point in corners),
                          min(point.y for point in corners),
                          min(start.z, end.z)))
        maximum = Vector((max(point.x for point in corners),
                          max(point.y for point in corners),
                          max(start.z, end.z) + headroom))
        result.append({
            "id": "SEGMENT_%03d" % index,
            "minimum": minimum,
            "maximum": maximum,
            "kind": segment.get("type", "segment"),
        })
    if result:
        return result

    # Last-resort legacy read from actual clearance volumes.
    for obj in descendants(circulation):
        if obj.get("SP_ROLE") not in {"CLEARANCE", "EXCLUSION", "OPENING_RESERVATION"}:
            continue
        points = [circulation.matrix_local @ obj.matrix_local @ Vector(corner)
                  for corner in obj.bound_box]
        result.append({
            "id": obj.get("SP_ID", obj.name),
            "minimum": Vector(tuple(min(point[axis] for point in points) for axis in range(3))),
            "maximum": Vector(tuple(max(point[axis] for point in points) for axis in range(3))),
            "kind": obj.get("SP_ROLE", "CLEARANCE"),
        })
    return result


def source_signature(host, circulation):
    sockets = [{
        "id": obj.get("SP_ID", ""),
        "level": int(obj.get("SP_LEVEL", 0)),
        "location": [round(value, 5) for value in obj.location],
        "footprint": [round(float(value), 5) for value in obj.get("SP_FOOTPRINT", (0, 0, 0))],
    } for obj in host_sockets(host)]
    accesses = [{
        "source_socket": item["source_socket"],
        "node_id": item["node_id"],
        "location": [round(value, 5) for value in item["location"]],
        "outward_direction": [round(value, 5) for value in item["outward_direction"]],
        "depth_direction": [round(value, 5) for value in item["depth_direction"]],
        "frontage_width": round(float(item["frontage_width"]), 5),
        "apron_depth": round(float(item["apron_depth"]), 5),
        "reachable": item["reachable"],
    } for item in access_contracts(host, circulation)]
    exclusion_records = [{
        "id": item["id"],
        "minimum": [round(value, 5) for value in item["minimum"]],
        "maximum": [round(value, 5) for value in item["maximum"]],
        "kind": item["kind"],
    } for item in restrictions(circulation)]
    payload = json.dumps({
        "host_id": host.get("SP_INSTANCE_ID", host.name) if host else "",
        "host_version": host.get("SP_GENERATOR_VERSION", "") if host else "",
        "circulation_id": circulation.get("SP_INSTANCE_ID", circulation.name) if circulation else "",
        "circulation_version": circulation.get("SP_GENERATOR_VERSION", "") if circulation else "",
        "circulation_signature": circulation.get("SP_SOURCE_SIGNATURE", "") if circulation else "",
        "sockets": sockets,
        "accesses": accesses,
        "restrictions": exclusion_records,
    }, sort_keys=True)
    return hashlib.sha1(payload.encode("utf-8")).hexdigest()
