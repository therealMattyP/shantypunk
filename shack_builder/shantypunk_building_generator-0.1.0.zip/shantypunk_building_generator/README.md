# Shantypunk Building Generator v0.1

Fits editable, midground proxy buildings to a selected Shantypunk Host and its
Circulation Controller. The add-on communicates only through public object
custom properties and JSON manifests; it does not import either generator.

## Requirements

- Blender 4.5 or newer; developed for Blender 5.1
- Shantypunk Host Generator v0.2 output
- A child Shantypunk Circulation Controller (v0.1 fallback or v0.2 contract)

## Workflow

1. Select a Host, Circulation, or generated child object.
2. Open **Shantypunk > Building Generator** in the 3D View sidebar.
3. Set the seeded use mix and fitting constraints.
4. Choose **Generate Buildings**.
5. Select the Building Controller or any proxy and use **Update Buildings**.

The Building Controller is parented to the Host Controller. Moving the host
moves circulation and buildings together. Multiple hosts retain independent
settings, controllers, manifests, validation reports, and stable IDs.

## v0.1 output

- Opaque residential, storefront, and utility/storage proxy cells
- Simple door, window/storefront, roof, and frontage indicators
- Stable cell IDs and source socket/access node references
- Support, entrance direction, footprint, use, and Flush/Reveal/Overlap metadata
- Access-apron and candidate-volume planning overlays (hidden by default)
- Source signatures, stale-source detection, manifest, and validation report

Cell fitting follows:

`candidate volume - circulation exclusions - openings - access apron = usable cell`

Circulation v0.2 `access_contracts`, `exclusions`, and
`opening_reservations` are consumed when present. Existing v0.1 scenes are
supported by inferring entrance direction from access and landing nodes and by
building semantic bounds from circulation segments. Proxy materials are opaque;
only optional planning overlays use transparent debug materials.

This first version creates planning-grade cells. It intentionally does not yet
replace them with detailed Shack Builder or Stockyard assemblies.

