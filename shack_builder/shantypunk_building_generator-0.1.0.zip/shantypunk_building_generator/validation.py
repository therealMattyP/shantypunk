import bpy

from . import contracts, metadata


def validate(controller, host_controller, circulation_controller, manifest):
    issues = []
    if not controller or controller.get("SP_ROLE") != "BUILDING_CONTROLLER":
        issues.append({"severity": "ERROR", "code": "NO_BUILDING_CONTROLLER"})
    if not host_controller or host_controller.get("SP_ROLE") != "HOST_CONTROLLER":
        issues.append({"severity": "ERROR", "code": "NO_SOURCE_HOST"})
    if not circulation_controller or circulation_controller.get("SP_ROLE") != "CIRCULATION_CONTROLLER":
        issues.append({"severity": "ERROR", "code": "NO_SOURCE_CIRCULATION"})
    if controller and host_controller and controller.parent != host_controller:
        issues.append({"severity": "ERROR", "code": "CONTROLLER_NOT_PARENTED_TO_HOST"})

    collection = bpy.data.collections.get(controller.get("SP_INSTANCE_COLLECTION", "")) if controller else None
    objects = list(collection.all_objects) if collection else []
    if not collection:
        issues.append({"severity": "ERROR", "code": "NO_INSTANCE_COLLECTION"})
    ids = {}
    for obj in objects:
        stable_id = obj.get("SP_ID")
        if not stable_id:
            issues.append({"severity": "ERROR", "code": "MISSING_ID", "object": obj.name})
            continue
        ids.setdefault(stable_id, []).append(obj.name)
        if obj != controller and obj.parent != controller:
            issues.append({"severity": "ERROR", "code": "WRONG_PARENT", "object": obj.name})
        if obj.get("SP_ROLE") != "BUILDING_CONTROLLER":
            if any(abs(value - 1.0) > 1e-5 for value in obj.scale):
                issues.append({"severity": "ERROR", "code": "UNAPPLIED_SCALE", "object": obj.name})
            if any(abs(value) > 1e-5 for value in obj.rotation_euler):
                issues.append({"severity": "ERROR", "code": "UNAPPLIED_ROTATION", "object": obj.name})
        if obj.type == 'MESH' and obj.get("SP_ROLE") in {"BUILDING_CELL", "BUILDING_FEATURE"}:
            for material in obj.data.materials:
                if material and material.diffuse_color[3] < 0.999:
                    issues.append({"severity": "ERROR", "code": "TRANSLUCENT_PROXY", "object": obj.name})
    for stable_id, names in ids.items():
        if len(names) > 1:
            issues.append({
                "severity": "ERROR", "code": "DUPLICATE_ID",
                "details": {"id": stable_id, "objects": names},
            })

    source_sockets = {obj.get("SP_ID") for obj in contracts.host_sockets(host_controller)}
    access_contracts = {
        item["node_id"]: item for item in contracts.access_contracts(host_controller, circulation_controller)
    }
    seen_sources = set()
    for cell in manifest.get("cells", []):
        cell_id = cell.get("id")
        if cell.get("source_socket") not in source_sockets:
            issues.append({"severity": "ERROR", "code": "MISSING_SOURCE_SOCKET", "details": cell_id})
        if cell.get("source_socket") in seen_sources:
            issues.append({"severity": "ERROR", "code": "DUPLICATE_SOURCE_SOCKET", "details": cell_id})
        seen_sources.add(cell.get("source_socket"))
        access = access_contracts.get(cell.get("access_node"))
        if not access:
            issues.append({"severity": "ERROR", "code": "MISSING_ACCESS_NODE", "details": cell_id})
        elif not access.get("reachable", False) or not cell.get("reachable", False):
            issues.append({"severity": "ERROR", "code": "UNREACHABLE_BUILDING_ACCESS", "details": cell_id})
        if cell.get("relationship") not in {"FLUSH", "REVEAL", "OVERLAP"}:
            issues.append({"severity": "ERROR", "code": "UNKNOWN_RELATIONSHIP", "details": cell_id})
        if cell.get("use") not in {"RESIDENTIAL", "STOREFRONT", "UTILITY_STORAGE"}:
            issues.append({"severity": "ERROR", "code": "UNKNOWN_BUILDING_USE", "details": cell_id})
        footprint = cell.get("footprint", (0.0, 0.0, 0.0))
        if len(footprint) < 3 or min(footprint) <= 0.0:
            issues.append({"severity": "ERROR", "code": "INVALID_FOOTPRINT", "details": cell_id})
        apron = cell.get("access_apron", {})
        if apron.get("depth", 0.0) <= 0.0 or apron.get("width", 0.0) <= 0.0:
            issues.append({"severity": "ERROR", "code": "INVALID_ACCESS_APRON", "details": cell_id})

    if not manifest.get("cells"):
        issues.append({
            "severity": "WARNING", "code": "NO_ACCEPTED_CELLS",
            "details": "No reachable candidate was large enough after restrictions",
        })
    if host_controller and circulation_controller:
        current_signature = contracts.source_signature(host_controller, circulation_controller)
        if manifest.get("source_signature") != current_signature:
            issues.append({
                "severity": "WARNING", "code": "SOURCE_CHANGED",
                "details": "Update buildings to match the current host and circulation contracts",
            })
    summary = {
        severity: sum(1 for item in issues if item["severity"] == severity)
        for severity in ("ERROR", "WARNING", "INFO")
    }
    return {"summary": summary, "issues": issues}


def write_report(report, text_name=metadata.VALIDATION_TEXT):
    lines = ["SHANTYPUNK BUILDING GENERATOR VALIDATION", "=" * 64]
    lines.extend("%s: %d" % (name, count) for name, count in report["summary"].items())
    lines.append("")
    for item in report["issues"]:
        lines.append("%s %s %s" % (
            item["severity"], item["code"], item.get("object", item.get("details", ""))))
    text = bpy.data.texts.get(text_name) or bpy.data.texts.new(text_name)
    text.clear()
    text.write("\n".join(lines))
    return lines

