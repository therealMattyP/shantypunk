bl_info = {
    "name": "Shantypunk Building Generator",
    "author": "Shantypunk",
    "version": (0, 1, 0),
    "blender": (4, 5, 0),
    "location": "View3D > Sidebar > Shantypunk",
    "description": "Fit proxy building cells to Shantypunk host and circulation contracts",
    "category": "Object",
}

from . import properties, ui


def register():
    properties.register()
    ui.register()


def unregister():
    ui.unregister()
    properties.unregister()

