import math

import bpy
from mathutils import Vector


MATERIALS = {
    "RESIDENTIAL": (0.43, 0.24, 0.12, 1.0),
    "STOREFRONT": (0.08, 0.34, 0.37, 1.0),
    "UTILITY_STORAGE": (0.30, 0.32, 0.34, 1.0),
    "ROOF": (0.10, 0.12, 0.13, 1.0),
    "DOOR": (0.07, 0.055, 0.04, 1.0),
    "WINDOW": (0.11, 0.29, 0.38, 1.0),
    "FRONTAGE": (0.94, 0.38, 0.06, 1.0),
    "DEBUG_APRON": (1.0, 0.32, 0.03, 0.20),
    "DEBUG_CANDIDATE": (0.08, 0.68, 1.0, 0.12),
}


def ensure_collection(name, parent=None):
    collection = bpy.data.collections.get(name) or bpy.data.collections.new(name)
    parent = parent or bpy.context.scene.collection
    if collection.name not in {child.name for child in parent.children}:
        parent.children.link(collection)
    return collection


def remove_collection(name):
    collection = bpy.data.collections.get(name)
    if not collection:
        return
    for child in list(collection.children):
        remove_collection(child.name)
    for obj in list(collection.objects):
        bpy.data.objects.remove(obj, do_unlink=True)
    bpy.data.collections.remove(collection)


def material(name):
    rgba = MATERIALS[name]
    data_name = "SPB_" + name
    mat = bpy.data.materials.get(data_name) or bpy.data.materials.new(data_name)
    mat.diffuse_color = rgba
    mat.use_nodes = True
    shader = mat.node_tree.nodes.get("Principled BSDF")
    if shader:
        shader.inputs["Base Color"].default_value = rgba
        shader.inputs["Roughness"].default_value = 0.76
        if "Alpha" in shader.inputs:
            shader.inputs["Alpha"].default_value = rgba[3]
    if rgba[3] < 1.0:
        try:
            mat.surface_render_method = 'DITHERED'
        except Exception:
            pass
    return mat


def move_to_collection(obj, collection):
    for owner in list(obj.users_collection):
        owner.objects.unlink(obj)
    collection.objects.link(obj)


def assign_material(obj, mat):
    if obj.data and hasattr(obj.data, "materials"):
        obj.data.materials.append(mat)


def box(name, center, dimensions, collection, mat=None, angle=0.0, bevel=0.0):
    bpy.ops.mesh.primitive_cube_add(location=Vector(center), rotation=(0.0, 0.0, angle))
    obj = bpy.context.object
    obj.name = name
    obj.dimensions = Vector(dimensions)
    bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)
    move_to_collection(obj, collection)
    if mat:
        assign_material(obj, mat)
    if bevel:
        modifier = obj.modifiers.new("SPB_Edge_Soften", 'BEVEL')
        modifier.width = bevel
        modifier.segments = 2
        modifier.limit_method = 'ANGLE'
    return obj


def empty(name, location, collection, display='CUBE', size=0.55):
    obj = bpy.data.objects.new(name, None)
    collection.objects.link(obj)
    obj.location = Vector(location)
    obj.empty_display_type = display
    obj.empty_display_size = size
    obj.show_in_front = True
    obj.hide_render = True
    return obj


def debug_box(name, center, dimensions, collection, material_name, angle=0.0, visible=False):
    obj = box(name, center, dimensions, collection, material(material_name), angle)
    obj.display_type = 'WIRE'
    obj.show_in_front = True
    obj.hide_render = True
    obj.hide_viewport = not visible
    obj["SP_DEBUG_VOLUME"] = True
    return obj


def angle_of(vector):
    vector = Vector(vector)
    return math.atan2(vector.y, vector.x)

