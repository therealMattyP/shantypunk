import json
import math
import random

import bpy
from mathutils import Vector

from . import contracts, geometry as geo, metadata, properties, validation


def next_instance_id():
    used = {
        obj.get("SP_INSTANCE_ID") for obj in bpy.data.objects
        if obj.get("SP_ROLE") == "BUILDING_CONTROLLER"
    }
    index = 1
    while "B%04d" % index in used:
        index += 1
    return "B%04d" % index


def instance_collection_name(instance_id):
    return "SP_BUILDINGS_%s" % instance_id


def create_controller(context, host_controller, circulation_controller):
    root = geo.ensure_collection(metadata.ROOT_COLLECTION)
    instance_id = next_instance_id()
    collection = geo.ensure_collection(instance_collection_name(instance_id), root)
    name = "SPB_%s_CONTROLLER" % instance_id
    controller = geo.empty(name, (0.0, 0.0, 0.0), collection, 'CUBE', 0.72)
    controller.parent = host_controller
    controller.location = (0.0, 0.0, 0.0)
    metadata.tag(
        controller, name, "BUILDING_CONTROLLER", instance_id,
        host_controller.get("SP_INSTANCE_ID", host_controller.name), 0, "",
        SP_INSTANCE_COLLECTION=collection.name,
        SP_SOURCE_HOST_CONTROLLER=host_controller.name,
        SP_SOURCE_CIRCULATION_CONTROLLER=circulation_controller.name,
    )
    properties.copy_settings(context.scene.sp_building_settings,
                             controller.sp_building_settings)
    return controller, collection


def clear_generated(controller):
    instance_id = controller.get("SP_INSTANCE_ID")
    for suffix in ("_GEOMETRY", "_FEATURES", "_DEBUG"):
        geo.remove_collection("SP_BUILDINGS_%s%s" % (instance_id, suffix))


def _collection_for(controller):
    collection = bpy.data.collections.get(controller.get("SP_INSTANCE_COLLECTION", ""))
    if collection:
        return collection
    root = geo.ensure_collection(metadata.ROOT_COLLECTION)
    collection = geo.ensure_collection(instance_collection_name(controller["SP_INSTANCE_ID"]), root)
    controller["SP_INSTANCE_COLLECTION"] = collection.name
    if controller.name not in collection.objects:
        collection.objects.link(controller)
    return collection


class BuildContext:
    def __init__(self, settings, controller, host, circulation, instance_collection):
        self.s = settings
        self.controller = controller
        self.host = host
        self.circulation = circulation
        self.instance_id = controller["SP_INSTANCE_ID"]
        self.host_id = host.get("SP_INSTANCE_ID", host.name)
        self.circulation_id = circulation.get("SP_INSTANCE_ID", circulation.name)
        self.rng = random.Random(settings.seed)
        prefix = "SP_BUILDINGS_%s" % self.instance_id
        self.geometry = geo.ensure_collection(prefix + "_GEOMETRY", instance_collection)
        self.features = geo.ensure_collection(prefix + "_FEATURES", instance_collection)
        self.debug = geo.ensure_collection(prefix + "_DEBUG", instance_collection)
        self.objects = []
        self.cells = []
        self.rejected = []
        self.restrictions = contracts.restrictions(circulation)
        self.object_index = 0

    def stable_id(self, local_id):
        return "SPB_%s_%s" % (self.instance_id, local_id)

    def register(self, obj, local_id, role, level=0, support_id="", **extra):
        stable_id = self.stable_id(local_id)
        obj.name = stable_id
        obj.parent = self.controller
        metadata.tag(obj, stable_id, role, self.instance_id, self.host_id,
                     level, support_id, SP_LOCAL_ID=local_id, **extra)
        self.objects.append(obj)
        return obj

    def feature(self, obj, cell_id, feature_type, level, support_id):
        self.object_index += 1
        return self.register(
            obj, "FEATURE_%04d" % self.object_index, "BUILDING_FEATURE",
            level, support_id, SP_CELL_ID=cell_id, SP_FEATURE_TYPE=feature_type)


def _socket_footprint(socket):
    values = socket.get("SP_FOOTPRINT", (3.6, 4.2, 3.0))
    try:
        result = tuple(max(0.01, float(value)) for value in values[:3])
    except (TypeError, ValueError, AttributeError):
        result = (3.6, 4.2, 3.0)
    return result if len(result) == 3 else (3.6, 4.2, 3.0)


def _half_extent(footprint, direction):
    direction = Vector(direction)
    return abs(direction.x) * footprint[0] * 0.5 + abs(direction.y) * footprint[1] * 0.5


def _project_aabb(record, origin, axis):
    minimum, maximum = record["minimum"], record["maximum"]
    values = []
    for x in (minimum.x, maximum.x):
        for y in (minimum.y, maximum.y):
            values.append((Vector((x, y, origin.z)) - origin).dot(axis))
    return min(values), max(values)


def _free_depth_interval(origin, depth_axis, side_axis, frontage, height, maximum_depth,
                         restrictions):
    """Find the closest usable interval behind an entrance in host-local space."""
    blocked = []
    half_frontage = frontage * 0.5
    for record in restrictions:
        if record["maximum"].z <= origin.z + 0.03 or record["minimum"].z >= origin.z + height:
            continue
        side_min, side_max = _project_aabb(record, origin, side_axis)
        if side_max <= -half_frontage + 0.02 or side_min >= half_frontage - 0.02:
            continue
        depth_min, depth_max = _project_aabb(record, origin, depth_axis)
        start, end = max(0.0, depth_min), min(maximum_depth, depth_max)
        if end - start > 0.025:
            blocked.append((start, end, record["id"]))
    blocked.sort()
    free = []
    cursor = 0.0
    active_ids = []
    for start, end, stable_id in blocked:
        if start > cursor + 0.04:
            free.append((cursor, start - 0.04, tuple(active_ids)))
        cursor = max(cursor, end + 0.04)
        active_ids.append(stable_id)
    if cursor < maximum_depth:
        free.append((cursor, maximum_depth, tuple(active_ids)))
    return max(free, key=lambda item: (item[1] - item[0], -item[0])) if free else None


def _weighted_use(settings, rng):
    choices = (
        ("RESIDENTIAL", settings.residential_weight),
        ("STOREFRONT", settings.storefront_weight),
        ("UTILITY_STORAGE", settings.utility_weight),
    )
    total = sum(max(0.0, weight) for _name, weight in choices)
    if total <= 1e-8:
        return "RESIDENTIAL"
    value = rng.random() * total
    cursor = 0.0
    for name, weight in choices:
        cursor += max(0.0, weight)
        if value <= cursor:
            return name
    return "RESIDENTIAL"


def _relationship(level, seen_levels, rng):
    if level not in seen_levels:
        return "FLUSH"
    value = rng.random()
    if value < 0.50:
        return "FLUSH"
    return "REVEAL" if value < 0.78 else "OVERLAP"


def _add_front_features(ctx, cell, front_center, depth_axis, side_axis, angle,
                        frontage, height, use, level, support_id):
    outward = -depth_axis
    surface = front_center + outward * 0.035
    cell_id = cell["SP_ID"]
    door_height = min(2.05, height * 0.82)
    if use == "UTILITY_STORAGE":
        door_width = min(frontage * 0.72, 2.45)
        door_height = min(2.35, height * 0.88)
    else:
        door_width = min(0.92, frontage * 0.32)
    door_center = surface + Vector((0, 0, door_height * 0.5 + 0.04))
    door = geo.box("door", door_center, (0.07, door_width, door_height),
                   ctx.features, geo.material("DOOR"), angle, 0.008)
    ctx.feature(door, cell_id, "UTILITY_DOOR" if use == "UTILITY_STORAGE" else "ENTRY_DOOR",
                level, support_id)

    if use == "STOREFRONT":
        panel_width = max(0.5, (frontage - door_width) * 0.72)
        panel_center = surface + side_axis * ((door_width + panel_width) * 0.31)
        panel_center.z += min(1.25, height * 0.48)
        panel = geo.box("storefront", panel_center, (0.065, panel_width, min(1.55, height * 0.58)),
                        ctx.features, geo.material("WINDOW"), angle, 0.006)
        ctx.feature(panel, cell_id, "STOREFRONT_GLAZING", level, support_id)
    elif use == "RESIDENTIAL" and frontage > 2.2:
        window_width = min(0.82, frontage * 0.24)
        window_center = surface - side_axis * min(frontage * 0.27, 1.0)
        window_center.z += min(1.42, height * 0.54)
        window = geo.box("window", window_center, (0.06, window_width, 0.86),
                         ctx.features, geo.material("WINDOW"), angle, 0.006)
        ctx.feature(window, cell_id, "WINDOW_PROXY", level, support_id)

    indicator_center = surface + Vector((0, 0, min(2.32, height * 0.90)))
    indicator = geo.box("frontage", indicator_center, (0.055, min(frontage, 2.2), 0.10),
                        ctx.features, geo.material("FRONTAGE"), angle, 0.004)
    ctx.feature(indicator, cell_id, "FRONTAGE_INDICATOR", level, support_id)


def _build_cell(ctx, index, socket, access, relationship):
    footprint = _socket_footprint(socket)
    candidate_center = socket.location.copy()
    entrance = Vector(access["location"])
    entrance.z = candidate_center.z
    depth_axis = Vector(access["depth_direction"])
    depth_axis.z = 0.0
    if depth_axis.length < 1e-5:
        depth_axis = Vector((0.0, 1.0, 0.0))
    depth_axis.normalize()
    side_axis = Vector((-depth_axis.y, depth_axis.x, 0.0))
    candidate_depth = _half_extent(footprint, depth_axis)
    candidate_side = _half_extent(footprint, side_axis)
    offset = (entrance - candidate_center).dot(depth_axis)
    maximum_depth = candidate_depth - offset - ctx.s.rear_margin
    contract_frontage = float(access.get("frontage_width", 0.0))
    frontage = min(2.0 * candidate_side - 2.0 * ctx.s.side_margin,
                   contract_frontage if contract_frontage > 0.0 else float("inf"))
    height = footprint[2] * ctx.s.height_factor
    if frontage < ctx.s.minimum_frontage or maximum_depth < ctx.s.minimum_depth:
        return None, "CANDIDATE_TOO_SMALL"
    interval = _free_depth_interval(
        entrance, depth_axis, side_axis, frontage, height, maximum_depth,
        ctx.restrictions)
    if not interval or interval[1] - interval[0] < ctx.s.minimum_depth:
        return None, "CIRCULATION_EXCLUSION"
    start_depth, end_depth, exclusion_ids = interval
    depth = end_depth - start_depth
    use = _weighted_use(ctx.s, ctx.rng)
    angle = geo.angle_of(depth_axis)
    center = entrance + depth_axis * (start_depth + depth * 0.5)
    center.z += height * 0.5
    support_id = socket.get("SP_SUPPORT_ID", "GROUND")
    local_id = "CELL_%03d" % index
    body = geo.box(
        local_id, center, (depth, frontage, height), ctx.geometry,
        geo.material(use), angle, 0.025)
    actual_footprint = (round(depth, 5), round(frontage, 5), round(height, 5))
    source_socket = socket.get("SP_ID", socket.name)
    source_access = access.get("node_id", "")
    outward = -depth_axis
    cell = ctx.register(
        body, local_id, "BUILDING_CELL", int(socket.get("SP_LEVEL", 0)), support_id,
        SP_BUILDING_USE=use,
        SP_RELATIONSHIP=relationship,
        SP_HEIGHT_RELATIONSHIP=relationship,
        SP_SOURCE_SOCKET=source_socket,
        SP_ACCESS_NODE=source_access,
        SP_ENTRANCE_DIRECTION=tuple(outward),
        SP_SOURCE_SOCKET_DIRECTION=tuple(socket.get("SP_SOCKET_DIRECTION", outward)),
        SP_FOOTPRINT=actual_footprint,
        SP_CANDIDATE_FOOTPRINT=footprint,
        SP_EXCLUSION_IDS_JSON=json.dumps(list(exclusion_ids)),
        SP_REACHABLE_ACCESS=bool(access.get("reachable", False)),
    )
    roof_center = center + Vector((0.0, 0.0, height * 0.5 + 0.045))
    roof = geo.box("roof", roof_center, (depth + 0.16, frontage + 0.18, 0.09),
                   ctx.features, geo.material("ROOF"), angle, 0.012)
    ctx.feature(roof, cell["SP_ID"], "ROOF_CAP", int(socket.get("SP_LEVEL", 0)), support_id)
    front_center = entrance + depth_axis * start_depth
    _add_front_features(
        ctx, cell, front_center, depth_axis, side_axis, angle, frontage, height,
        use, int(socket.get("SP_LEVEL", 0)), support_id)

    apron_depth = max(ctx.s.access_apron_depth, float(access.get("apron_depth", 0.0))) + start_depth
    apron_center = front_center + outward * (apron_depth * 0.5)
    apron_center.z += 0.035
    apron = geo.debug_box(
        "apron", apron_center, (apron_depth, min(frontage, 1.8), 0.07),
        ctx.debug, "DEBUG_APRON", geo.angle_of(outward), ctx.s.show_planning_volumes)
    ctx.register(
        apron, "APRON_%03d" % index, "ACCESS_APRON", int(socket.get("SP_LEVEL", 0)),
        support_id, SP_CELL_ID=cell["SP_ID"], SP_NON_EXPORT=True,
        SP_SOURCE_ACCESS_NODE=source_access)
    candidate = geo.debug_box(
        "candidate", candidate_center + Vector((0, 0, footprint[2] * 0.5)), footprint,
        ctx.debug, "DEBUG_CANDIDATE", 0.0, ctx.s.show_planning_volumes)
    ctx.register(
        candidate, "CANDIDATE_%03d" % index, "CANDIDATE_VOLUME",
        int(socket.get("SP_LEVEL", 0)), support_id, SP_CELL_ID=cell["SP_ID"],
        SP_NON_EXPORT=True, SP_SOURCE_SOCKET=source_socket)

    record = {
        "id": cell["SP_ID"],
        "use": use,
        "level": int(socket.get("SP_LEVEL", 0)),
        "relationship": relationship,
        "source_socket": source_socket,
        "access_node": source_access,
        "support_id": support_id,
        "entrance_location": list(front_center),
        "entrance_direction": list(outward),
        "footprint": list(actual_footprint),
        "candidate_footprint": list(footprint),
        "access_apron": {
            "depth": apron_depth,
            "width": min(frontage, 1.8),
            "center": list(apron_center),
        },
        "restriction_ids": list(exclusion_ids),
        "reachable": bool(access.get("reachable", False)),
    }
    ctx.cells.append(record)
    return cell, "ACCEPTED"


def solve(ctx):
    sockets = contracts.host_sockets(ctx.host)
    accesses = contracts.access_contracts(ctx.host, ctx.circulation)
    by_socket = {item["source_socket"]: item for item in accesses if item["source_socket"]}
    seen_levels = set()
    for index, socket in enumerate(sockets):
        source_socket = socket.get("SP_ID", socket.name)
        access = by_socket.get(source_socket)
        if not access:
            ctx.rejected.append({"source_socket": source_socket, "reason": "NO_ACCESS_CONTRACT"})
            continue
        if not access.get("reachable", False):
            ctx.rejected.append({"source_socket": source_socket, "reason": "UNREACHABLE_ACCESS"})
            continue
        if ctx.rng.random() > ctx.s.density:
            ctx.rejected.append({"source_socket": source_socket, "reason": "DENSITY"})
            continue
        level = int(socket.get("SP_LEVEL", 0))
        relationship = _relationship(level, seen_levels, ctx.rng)
        _cell, reason = _build_cell(ctx, index, socket, access, relationship)
        if reason == "ACCEPTED":
            seen_levels.add(level)
        else:
            ctx.rejected.append({"source_socket": source_socket, "reason": reason})


def generate(context, host_controller=None, controller=None):
    if controller:
        host_controller = contracts.host_controller_from_object(controller)
        if not host_controller:
            raise ValueError("The Building Controller is no longer attached to a Host Controller")
        circulation = contracts.circulation_for_host(host_controller)
        if not circulation:
            raise ValueError("The source host has no Circulation Controller")
        collection = _collection_for(controller)
        clear_generated(controller)
    else:
        if not host_controller:
            raise ValueError("Select a Host Controller with generated circulation")
        circulation = contracts.circulation_for_host(host_controller)
        if not circulation:
            raise ValueError("Generate circulation for the selected host first")
        existing = contracts.building_for_host(host_controller)
        if existing:
            controller = existing
            collection = _collection_for(controller)
            clear_generated(controller)
        else:
            controller, collection = create_controller(context, host_controller, circulation)

    controller["SP_SOURCE_HOST_CONTROLLER"] = host_controller.name
    controller["SP_SOURCE_CIRCULATION_CONTROLLER"] = circulation.name
    settings = controller.sp_building_settings
    ctx = BuildContext(settings, controller, host_controller, circulation, collection)
    solve(ctx)
    signature = contracts.source_signature(host_controller, circulation)
    manifest = {
        "schema_version": metadata.SCHEMA_VERSION,
        "generator_version": metadata.GENERATOR_VERSION,
        "instance_id": ctx.instance_id,
        "controller": controller.name,
        "source_host_id": ctx.host_id,
        "source_host_controller": host_controller.name,
        "source_circulation_id": ctx.circulation_id,
        "source_circulation_controller": circulation.name,
        "source_signature": signature,
        "cells": ctx.cells,
        "rejected_candidates": ctx.rejected,
        "restrictions_considered": [record["id"] for record in ctx.restrictions],
        "contracts": {
            "cell_formula": "candidate - circulation exclusions - openings - access apron",
            "supported_access_contract_versions": ["circulation_0.1_fallback", "circulation_0.2"],
            "minimum_depth": settings.minimum_depth,
            "minimum_frontage": settings.minimum_frontage,
            "minimum_access_apron": settings.access_apron_depth,
        },
    }
    report = validation.validate(controller, host_controller, circulation, manifest)
    manifest["validation"] = report["summary"]
    manifest_name = "%s_%s" % (metadata.MANIFEST_TEXT, ctx.instance_id)
    validation_name = "%s_%s" % (metadata.VALIDATION_TEXT, ctx.instance_id)
    text = bpy.data.texts.get(manifest_name) or bpy.data.texts.new(manifest_name)
    text.clear()
    text.write(json.dumps(manifest, indent=2))
    validation.write_report(report, validation_name)
    controller["SP_MANIFEST_TEXT"] = manifest_name
    controller["SP_VALIDATION_TEXT"] = validation_name
    controller["SP_SOURCE_SIGNATURE"] = signature
    controller["SP_BUILDING_VALID"] = report["summary"]["ERROR"] == 0
    controller["SP_GENERATOR_VERSION"] = metadata.GENERATOR_VERSION
    bpy.ops.object.select_all(action='DESELECT')
    controller.select_set(True)
    context.view_layer.objects.active = controller
    return manifest, report, controller


def validate_controller(controller):
    host = contracts.host_controller_from_object(controller)
    circulation = contracts.circulation_for_host(host)
    text = bpy.data.texts.get(controller.get("SP_MANIFEST_TEXT", "")) if controller else None
    if not host or not circulation or not text:
        return None
    manifest = json.loads(text.as_string())
    report = validation.validate(controller, host, circulation, manifest)
    validation.write_report(
        report, controller.get("SP_VALIDATION_TEXT", metadata.VALIDATION_TEXT))
    controller["SP_BUILDING_VALID"] = report["summary"]["ERROR"] == 0
    return report


def delete_buildings(controller):
    if not controller:
        return False
    collection_name = controller.get("SP_INSTANCE_COLLECTION")
    manifest_name = controller.get("SP_MANIFEST_TEXT")
    validation_name = controller.get("SP_VALIDATION_TEXT")
    if collection_name:
        geo.remove_collection(collection_name)
    else:
        bpy.data.objects.remove(controller, do_unlink=True)
    for name in (manifest_name, validation_name):
        text = bpy.data.texts.get(name) if name else None
        if text:
            bpy.data.texts.remove(text)
    return True
