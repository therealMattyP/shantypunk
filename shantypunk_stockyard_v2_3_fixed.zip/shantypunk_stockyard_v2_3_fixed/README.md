# Stockyard v2.3

Stockyard v2 is the first construction-plausible procedural timber platform prototype for Shantypunk.

## Design rules

- Blender units are treated as meters.
- `Chaos = 0` produces deterministic, square, structurally legible construction.
- Randomness is seeded and belongs only to explicit imperfection controls.
- Generated parts are independent named objects with semantic `stockyard_role` metadata.
- The prototype targets midground visual quality and downstream refinement rather than joinery-level fabrication detail.

## Included structure

- Post grid based on width/depth bay counts
- Primary beams
- Joists at adjustable real-world spacing
- Individual deck boards with adjustable gaps
- Optional diagonal or cross bracing
- Multistory platform generation
- Framed floor openings reserved before posts, beams, joists, and decking
- Straight timber stairs, fixed ladders, perimeter rails, and opening rails
- Attachment sockets for future construction hosts

## Circulation ribbon prototype

Version 2.3 adds **Slope Ribbon** as the default circulation mode. It generates an abstract continuous route between finished deck levels before committing that route to stairs, a ladder, a fire escape, or another construction language.

The ribbon provides:

- Start and end access-point markers
- Flat landing proxies at both endpoints
- Adjustable direction, opening position, opening length, width, and clearances
- Horizontal run, vertical rise, and slope readout in the Blender panel
- Automatic interpretation as walkway, ramp, stairs, ship stair, or ladder
- Route metadata on generated objects for later circulation solving
- A diagnostic maximum-slope test stored as `route_valid`

The ribbon is intentionally not an accessibility-compliant constructed ramp. It is the style-agnostic circulation path that later systems will interpret using timber shanty stairs, scaffold stairs, fire escapes, ladders, bridges, or other assemblies.

## Explicit chaos controls

- Post lean
- Joist/member shift
- Joist twist
- Deck-board twist
- Deck-board end shift
- Deck-board height variation
- Missing-board probability
- Repair-board count

All chaos values are multiplied by the master `Chaos` slider. At zero, none of these deviations are applied.

## Installation

1. Copy the `stockyard_v2` folder into Blender's add-ons directory, or zip the folder and install it through Blender Preferences.
2. Enable **Shantypunk Stockyard v2**.
3. Open the 3D View sidebar.
4. Select the **Shantypunk** tab.
5. Adjust the controls and click **Generate Stockyard v2**.

The generator replaces the contents of the `STOCKYARD_V2` collection each time it runs.

## Current limitations

- Circulation routes are straight; L-shaped, switchback, and obstacle-avoiding routes are not solved yet.
- Access markers are regenerated from panel controls and are not independently draggable hosts yet.
- No roof, doors, walls, corrugated panels, or enclosed rooms yet.
- No material assignment or UV generation yet.
- No curve-driven footprint yet.
- Deck-board sag is represented only by per-board displacement/rotation; true curved sag is a later geometry pass.
- Braces are visual structural members and do not yet solve around collisions.

## Recommended next passes

1. Promote access markers to draggable scene hosts.
2. Add L-shaped and switchback circulation ribbons with landings.
3. Route around simple obstacle volumes.
4. Interpret routes as scaffold stairs and fire-escape assemblies.
5. Add wall and roof attachment hosts.
6. Add corrugated-sheet and scrap-board enclosure grammars.
7. Add material slots and deterministic material variation.
8. Add commit/bake workflow and Unreal-friendly export metadata.
