import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty, IntProperty, PointerProperty
from bpy.types import PropertyGroup


class SPHostSettings(PropertyGroup):
    preset: EnumProperty(name="Host Archetype", items=[
        ('TERRACED_HILLSIDE', "Terraced Hillside", "Stacked irregular buildable terrain shelves"),
        ('CONCRETE_TENEMENT', "Concrete Tenement", "Formal concrete host with adaptable facades and roof"),
        ('INDUSTRIAL_FRAME', "Industrial Frame", "Heavy open steel frame host"),
        ('TIMBER_FRAME', "Timber Frame", "Regular elevated timber post-and-platform host"),
        ('CONTAINER_STACK', "Container Stack", "Staggered standardized container host"),
        ('VERTICAL_CORE', "Vertical Core / Tree", "Radial platforms around a vertical obstruction"),
    ], default='TERRACED_HILLSIDE')
    seed: IntProperty(name="Seed", default=17, min=0, max=999999)
    levels: IntProperty(name="Levels", default=4, min=2, max=12)
    width: FloatProperty(name="Host Width", default=12.0, min=4.0, max=60.0, unit='LENGTH')
    depth: FloatProperty(name="Host Depth", default=9.0, min=4.0, max=50.0, unit='LENGTH')
    story_height: FloatProperty(name="Level Height", default=3.0, min=2.1, max=6.0, unit='LENGTH')
    walking_width: FloatProperty(name="Reserved Route Width", default=1.1, min=0.65, max=3.0, unit='LENGTH')
    headroom: FloatProperty(name="Reserved Headroom", default=2.15, min=1.9, max=4.0, unit='LENGTH')
    cell_width: FloatProperty(name="Nominal Cell Width", default=3.6, min=2.2, max=9.0, unit='LENGTH')
    cell_depth: FloatProperty(name="Nominal Cell Depth", default=4.2, min=2.2, max=10.0, unit='LENGTH')
    irregularity: FloatProperty(name="Host Irregularity", default=0.22, min=0.0, max=1.0, subtype='FACTOR')
    reserve_primary_spine: BoolProperty(name="Reserve Primary Circulation Spine", default=True)
    show_clearance: BoolProperty(name="Show Clearance Volumes", default=True)
    show_build_zones: BoolProperty(name="Show Build Zones", default=True)
    create_materials: BoolProperty(name="Create Preview Materials", default=True)


classes = (SPHostSettings,)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.sp_host_settings = PointerProperty(type=SPHostSettings)


def unregister():
    del bpy.types.Scene.sp_host_settings
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
