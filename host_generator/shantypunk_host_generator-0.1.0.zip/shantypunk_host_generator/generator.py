import bpy
import json
import math
import random
from mathutils import Vector
from . import geometry as geo, metadata, validation


class BuildContext:
    def __init__(self, settings):
        self.s = settings
        self.rng = random.Random(settings.seed)
        self.root = geo.ensure_collection(metadata.ROOT_COLLECTION)
        self.host = geo.ensure_collection(metadata.HOST_COLLECTION, self.root)
        self.sockets = geo.ensure_collection(metadata.SOCKET_COLLECTION, self.root)
        self.debug = geo.ensure_collection(metadata.DEBUG_COLLECTION, self.root)
        self.host_type = settings.preset
        self.host_objects = []
        self.socket_objects = []
        self.debug_objects = []
        self.nodes = []
        self.edges = []
        self.level_supports = {}

    def tag_host(self, obj, stable_id, role, level=0, support="GROUND", **extra):
        metadata.tag(obj, stable_id, role, self.host_type, level, support, **extra)
        self.host_objects.append(obj)
        return obj

    def socket(self, socket_type, level, location, support="GROUND", suffix="", direction=(0.0, 1.0, 0.0), footprint=None):
        stable_id = "SPH_%s_L%02d%s" % (socket_type, level, ("_" + suffix) if suffix else "")
        obj = geo.empty(stable_id, location, self.sockets, 'CUBE' if socket_type == 'CELL_ATTACH' else 'ARROWS', 0.32)
        metadata.tag(obj, stable_id, "SOCKET", self.host_type, level, support,
                     SP_SOCKET_TYPE=socket_type, SP_SOCKET_DIRECTION=direction,
                     SP_FOOTPRINT=footprint or (0.0, 0.0, 0.0))
        self.socket_objects.append(obj)
        return obj

    def debug_box(self, name, center, dimensions, role, level, support, material_name):
        obj = geo.debug_volume(name, center, dimensions, self.debug, material_name,
                               self.s.show_clearance if role == "CLEARANCE" else self.s.show_build_zones)
        self.tag_host(obj, name, role, level, support, SP_NON_EXPORT=True)
        self.debug_objects.append(obj)
        return obj


def setup():
    geo.remove_collection(metadata.ROOT_COLLECTION)
    return geo.ensure_collection(metadata.ROOT_COLLECTION)


def add_level_contract(ctx, level, center, support_id, zone_scale=(1.0, 1.0), side_count=2):
    z = center.z
    walk = ctx.socket("WALK_ANCHOR", level, center, support_id)
    ctx.nodes.append(walk["SP_ID"])
    if level == 0:
        entry = ctx.socket("GROUND_ENTRY", 0, center - Vector((0, ctx.s.walking_width, 0)), "GROUND")
        ctx.edges.append((entry["SP_ID"], walk["SP_ID"]))
        ctx.entry = entry["SP_ID"]
    else:
        ctx.edges.append(("SPH_WALK_ANCHOR_L%02d" % (level - 1), walk["SP_ID"]))
    ctx.socket("SUPPORT_DOWN", level, center - Vector((0, 0, 0.12)), support_id, direction=(0, 0, -1))
    ctx.socket("BRIDGE_ATTACH", level, center + Vector((ctx.s.width*0.42, 0, 0)), support_id, "E", (1, 0, 0))
    ctx.socket("BRIDGE_ATTACH", level, center - Vector((ctx.s.width*0.42, 0, 0)), support_id, "W", (-1, 0, 0))
    if ctx.s.reserve_primary_spine:
        ctx.debug_box("SPH_CLEARANCE_L%02d" % level,
                      center + Vector((0, 0, ctx.s.headroom*0.5)),
                      (ctx.s.walking_width, ctx.s.walking_width*1.6, ctx.s.headroom),
                      "CLEARANCE", level, support_id, "DEBUG_CLEARANCE")
    for side in range(side_count):
        sign = -1 if side == 0 else 1
        location = center + Vector((sign*(ctx.s.walking_width*0.5 + ctx.s.cell_width*0.55), 0, 0))
        socket = ctx.socket("CELL_ATTACH", level, location, support_id, "AB"[side],
                            (0, -1, 0), (ctx.s.cell_width*zone_scale[0], ctx.s.cell_depth*zone_scale[1], ctx.s.story_height))
        ctx.debug_box("SPH_BUILD_ZONE_L%02d_%s" % (level, "AB"[side]),
                      location + Vector((0, 0, ctx.s.story_height*0.5)),
                      socket["SP_FOOTPRINT"], "BUILD_ZONE", level, support_id, "DEBUG_BUILDABLE")


def terraced_hillside(ctx):
    mat = geo.material("HOST_TERRAIN")
    for level in range(ctx.s.levels):
        width = ctx.s.width * (1.0 - 0.055*level)
        shelf_depth = ctx.s.depth / ctx.s.levels + ctx.s.cell_depth
        y = level * (ctx.s.depth / ctx.s.levels) - ctx.s.depth*0.42
        jitter = ctx.s.irregularity * 0.6
        points = [
            (-width/2 + ctx.rng.uniform(-jitter, jitter), y-shelf_depth*0.55),
            ( width/2 + ctx.rng.uniform(-jitter, jitter), y-shelf_depth*0.48),
            ( width/2 + ctx.rng.uniform(-jitter, jitter), y+shelf_depth*0.52),
            (-width/2 + ctx.rng.uniform(-jitter, jitter), y+shelf_depth*0.45),
        ]
        top = level * ctx.s.story_height * 0.72
        support = "GROUND" if level == 0 else "SPH_TERRACE_L%02d" % (level-1)
        obj = geo.polygon_prism("SPH_TERRACE_L%02d" % level, points, -0.45, top, ctx.host, mat)
        ctx.tag_host(obj, obj.name, "TERRAIN_TERRACE", level, support, SP_BUILDABLE_TOP=True)
        ctx.level_supports[level] = obj.name
        add_level_contract(ctx, level, Vector((0, y, top)), obj.name, (0.88, 0.72))


def concrete_tenement(ctx):
    mat = geo.material("HOST_CONCRETE")
    wing = ctx.s.width*0.38
    gap = ctx.s.width*0.18
    for side, sign in (("A", -1), ("B", 1)):
        x0 = sign*(gap/2); x1 = sign*(gap/2+wing)
        minimum, maximum = ((min(x0,x1), -ctx.s.depth/2, 0), (max(x0,x1), ctx.s.depth/2, ctx.s.levels*ctx.s.story_height))
        obj = geo.box("SPH_TENEMENT_WING_"+side, minimum, maximum, ctx.host, mat, 0.035)
        ctx.tag_host(obj, obj.name, "FORMAL_HOST", 0, "GROUND", SP_BUILDING_WING=side)
    support = "SPH_TENEMENT_WING_A"
    for level in range(ctx.s.levels):
        z = level*ctx.s.story_height
        add_level_contract(ctx, level, Vector((0, -ctx.s.depth*0.46, z)), support, (0.72, 0.55))
        for sign, side in ((-1,"A"),(1,"B")):
            ctx.socket("WALL_ATTACH", level, (sign*(gap/2+0.02), -ctx.s.depth*0.35, z+ctx.s.story_height*0.5),
                       "SPH_TENEMENT_WING_"+side, side, (-sign,0,0))
    ctx.socket("ROOF_ATTACH", ctx.s.levels, (0, 0, ctx.s.levels*ctx.s.story_height), support, direction=(0,0,1))


def frame_host(ctx, timber=False):
    mat = geo.material("HOST_TIMBER" if timber else "HOST_STEEL")
    prefix = "TIMBER" if timber else "INDUSTRIAL"
    post = 0.18 if timber else 0.24
    xs = (-ctx.s.width/2, 0, ctx.s.width/2)
    ys = (-ctx.s.depth/2, ctx.s.depth/2)
    for ix, x in enumerate(xs):
        for iy, y in enumerate(ys):
            obj = geo.box("SPH_%s_POST_%d_%d" % (prefix, ix, iy),
                          (x-post/2,y-post/2,0), (x+post/2,y+post/2,ctx.s.levels*ctx.s.story_height), ctx.host, mat, 0.01)
            ctx.tag_host(obj, obj.name, "STRUCTURAL_POST", 0, "GROUND")
    for level in range(ctx.s.levels):
        z = level*ctx.s.story_height
        deck = geo.box("SPH_%s_DECK_L%02d" % (prefix, level),
                       (-ctx.s.width/2,-ctx.s.depth/2,z-0.16), (ctx.s.width/2,ctx.s.depth/2,z), ctx.host, mat, 0.008)
        ctx.tag_host(deck, deck.name, "HOST_PLATFORM", level, "SPH_%s_POST_0_0" % prefix, SP_BUILDABLE_TOP=True)
        add_level_contract(ctx, level, Vector((0,-ctx.s.depth*0.38,z)), deck.name, (0.9,0.7))
    ctx.socket("ROOF_ATTACH", ctx.s.levels, (0,0,ctx.s.levels*ctx.s.story_height), "SPH_%s_POST_0_0" % prefix, direction=(0,0,1))


def container_stack(ctx):
    mat = geo.material("HOST_CONTAINER")
    container_w, container_d, container_h = 2.438, 6.058, 2.591
    count_x = max(2, int(ctx.s.width // container_w))
    for level in range(ctx.s.levels):
        count = max(1, count_x - level//2)
        offset = (level % 2)*container_w*0.45
        for index in range(count):
            x = (index-(count-1)/2)*container_w + offset
            y = (level % 2)*container_d*0.18
            name = "SPH_CONTAINER_L%02d_%02d" % (level,index)
            obj = geo.box(name, (x-container_w/2,y-container_d/2,level*container_h),
                          (x+container_w/2,y+container_d/2,(level+1)*container_h), ctx.host, mat, 0.02)
            support = "GROUND" if level == 0 else "SPH_CONTAINER_L%02d_%02d" % (level-1,min(index,max(0,count_x-(level-1)//2-1)))
            ctx.tag_host(obj,name,"CONTAINER_HOST",level,support,SP_NO_CUT_CORNERS=True)
        support = "SPH_CONTAINER_L%02d_00" % level
        ctx.level_supports[level] = support
        add_level_contract(ctx, level, Vector((0,-container_d*0.56,level*container_h)), support, (0.65,0.55))


def vertical_core(ctx):
    core_mat, deck_mat = geo.material("HOST_CORE"), geo.material("HOST_TIMBER")
    core = geo.cylinder("SPH_VERTICAL_CORE", 0.72, ctx.s.levels*ctx.s.story_height+1.0,
                        (0,0,(ctx.s.levels*ctx.s.story_height+1.0)/2), ctx.host, core_mat, 24)
    ctx.tag_host(core,core.name,"VERTICAL_OBSTRUCTION",0,"GROUND",SP_NO_BUILD_RADIUS=0.95)
    for level in range(ctx.s.levels):
        angle = level*math.radians(78)
        center = Vector((math.cos(angle)*ctx.s.width*0.12, math.sin(angle)*ctx.s.depth*0.12, level*ctx.s.story_height))
        deck = geo.box("SPH_RADIAL_DECK_L%02d" % level,
                       center-Vector((ctx.s.cell_width,ctx.s.cell_depth,0.16))*0.5,
                       center+Vector((ctx.s.cell_width,ctx.s.cell_depth,0))*0.5, ctx.host, deck_mat, 0.01)
        ctx.tag_host(deck,deck.name,"RADIAL_PLATFORM",level,core.name,SP_BUILDABLE_TOP=True)
        add_level_contract(ctx,level,center,deck.name,(0.75,0.62),side_count=2)
    ctx.socket("ROOF_ATTACH",ctx.s.levels,(0,0,ctx.s.levels*ctx.s.story_height),core.name,direction=(0,0,1))


GENERATORS = {
    'TERRACED_HILLSIDE': terraced_hillside,
    'CONCRETE_TENEMENT': concrete_tenement,
    'INDUSTRIAL_FRAME': lambda ctx: frame_host(ctx, False),
    'TIMBER_FRAME': lambda ctx: frame_host(ctx, True),
    'CONTAINER_STACK': container_stack,
    'VERTICAL_CORE': vertical_core,
}


def generate(context):
    settings = context.scene.sp_host_settings
    setup()
    ctx = BuildContext(settings)
    GENERATORS[settings.preset](ctx)
    manifest = {
        "schema_version": metadata.SCHEMA_VERSION,
        "generator_version": metadata.GENERATOR_VERSION,
        "host_type": settings.preset,
        "seed": settings.seed,
        "host_objects": [obj["SP_ID"] for obj in ctx.host_objects if not obj.get("SP_NON_EXPORT")],
        "sockets": [{"id": obj["SP_ID"], "type": obj["SP_SOCKET_TYPE"], "level": obj["SP_LEVEL"],
                     "location": list(obj.location), "support_id": obj["SP_SUPPORT_ID"],
                     "direction": list(obj["SP_SOCKET_DIRECTION"])} for obj in ctx.socket_objects],
        "circulation_graph": {"entry": getattr(ctx,"entry",None), "nodes": ctx.nodes, "edges": ctx.edges},
        "contracts": {"walking_width": settings.walking_width, "headroom": settings.headroom,
                      "cell_width": settings.cell_width, "cell_depth": settings.cell_depth},
    }
    report = validation.validate(ctx.root, manifest)
    manifest["validation"] = report["summary"]
    text = bpy.data.texts.get(metadata.MANIFEST_TEXT) or bpy.data.texts.new(metadata.MANIFEST_TEXT)
    text.clear(); text.write(json.dumps(manifest, indent=2))
    validation.write_report(report)
    context.scene["SP_HOST_TYPE"] = settings.preset
    context.scene["SP_HOST_VALID"] = report["summary"]["ERROR"] == 0
    return manifest, report


def clear():
    geo.remove_collection(metadata.ROOT_COLLECTION)
