import bpy
from . import metadata


def validate(root, manifest):
    issues = []
    ids = {}
    for obj in root.all_objects:
        stable_id = obj.get("SP_ID")
        if not stable_id:
            issues.append({"severity": "ERROR", "code": "MISSING_ID", "object": obj.name})
            continue
        ids.setdefault(stable_id, []).append(obj.name)
        if any(abs(value - 1.0) > 1e-5 for value in obj.scale):
            issues.append({"severity": "ERROR", "code": "UNAPPLIED_SCALE", "object": obj.name})
        if any(abs(value) > 1e-5 for value in obj.rotation_euler):
            issues.append({"severity": "ERROR", "code": "UNAPPLIED_ROTATION", "object": obj.name})
        if obj.get("SP_ROLE") == "SOCKET" and obj.get("SP_SOCKET_TYPE") not in metadata.SOCKET_TYPES:
            issues.append({"severity": "ERROR", "code": "UNKNOWN_SOCKET", "object": obj.name})
    for stable_id, names in ids.items():
        if len(names) > 1:
            issues.append({"severity": "ERROR", "code": "DUPLICATE_ID", "details": {"id": stable_id, "objects": names}})
    existing = set(ids)
    for obj in root.all_objects:
        support = obj.get("SP_SUPPORT_ID")
        if support and support not in existing and support != "GROUND":
            issues.append({"severity": "ERROR", "code": "UNRESOLVED_SUPPORT", "object": obj.name, "details": support})
    if not any(obj.get("SP_SOCKET_TYPE") == "GROUND_ENTRY" for obj in root.all_objects):
        issues.append({"severity": "ERROR", "code": "NO_GROUND_ENTRY"})
    graph = manifest.get("circulation_graph", {})
    reachable = {graph.get("entry")}
    changed = True
    while changed:
        changed = False
        for edge in graph.get("edges", []):
            if edge[0] in reachable and edge[1] not in reachable:
                reachable.add(edge[1]); changed = True
    for node in graph.get("nodes", []):
        if node not in reachable:
            issues.append({"severity": "ERROR", "code": "UNREACHABLE_WALK_ANCHOR", "details": node})
    summary = {level: sum(1 for item in issues if item["severity"] == level) for level in ("ERROR", "WARNING", "INFO")}
    return {"summary": summary, "issues": issues}


def write_report(report):
    lines = ["SHANTYPUNK HOST GENERATOR VALIDATION", "=" * 64]
    lines.extend("%s: %d" % (name, count) for name, count in report["summary"].items())
    lines.append("")
    for item in report["issues"]:
        lines.append("{severity} {code} {object}".format(object=item.get("object", ""), **item))
    text = bpy.data.texts.get(metadata.VALIDATION_TEXT) or bpy.data.texts.new(metadata.VALIDATION_TEXT)
    text.clear(); text.write("\n".join(lines))
    return lines
