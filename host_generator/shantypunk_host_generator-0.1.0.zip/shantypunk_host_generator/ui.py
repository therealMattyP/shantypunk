import bpy
from bpy.types import Operator, Panel
from . import generator, metadata, validation


class SPHOST_OT_generate(Operator):
    bl_idname = "sphost.generate"
    bl_label = "Generate Host"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        manifest, report = generator.generate(context)
        errors = report["summary"]["ERROR"]
        if errors:
            self.report({'WARNING'}, "Host generated with %d validation errors" % errors)
        else:
            self.report({'INFO'}, "Validated %s host generated" % manifest["host_type"].replace('_',' ').title())
        return {'FINISHED'}


class SPHOST_OT_clear(Operator):
    bl_idname = "sphost.clear"
    bl_label = "Clear Generated Host"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        generator.clear()
        return {'FINISHED'}


class SPHOST_OT_validate(Operator):
    bl_idname = "sphost.validate"
    bl_label = "Validate Current Host"
    def execute(self, context):
        root = bpy.data.collections.get(metadata.ROOT_COLLECTION)
        text = bpy.data.texts.get(metadata.MANIFEST_TEXT)
        if not root or not text:
            self.report({'ERROR'}, "Generate a host first")
            return {'CANCELLED'}
        import json
        report = validation.validate(root, json.loads(text.as_string()))
        validation.write_report(report)
        self.report({'INFO' if not report['summary']['ERROR'] else 'WARNING'},
                    "%d errors, %d warnings" % (report['summary']['ERROR'],report['summary']['WARNING']))
        return {'FINISHED'}


class SPHOST_PT_panel(Panel):
    bl_label = "Host Generator"
    bl_idname = "SPHOST_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Shantypunk"
    def draw(self, context):
        layout = self.layout
        s = context.scene.sp_host_settings
        layout.prop(s,"preset")
        row = layout.row(align=True); row.prop(s,"levels"); row.prop(s,"seed")
        box = layout.box(); box.label(text="Host Envelope")
        box.prop(s,"width"); box.prop(s,"depth"); box.prop(s,"story_height"); box.prop(s,"irregularity")
        box = layout.box(); box.label(text="Planning Contracts")
        box.prop(s,"walking_width"); box.prop(s,"headroom"); box.prop(s,"cell_width"); box.prop(s,"cell_depth")
        box.prop(s,"reserve_primary_spine")
        box = layout.box(); box.label(text="Debug")
        box.prop(s,"show_clearance"); box.prop(s,"show_build_zones")
        layout.operator("sphost.generate",icon='MOD_BUILD')
        row=layout.row(align=True); row.operator("sphost.validate",icon='CHECKMARK'); row.operator("sphost.clear",icon='TRASH')


classes=(SPHOST_OT_generate,SPHOST_OT_clear,SPHOST_OT_validate,SPHOST_PT_panel)


def register():
    for cls in classes: bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes): bpy.utils.unregister_class(cls)
