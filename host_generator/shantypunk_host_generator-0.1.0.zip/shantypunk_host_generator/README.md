# Shantypunk Host Generator 0.1

Generates the load-bearing site or formal structure that later Shantypunk systems inhabit. It deliberately stops before finished circulation, rooms, enclosure, or dressing.

## Host archetypes

- Terraced Hillside
- Concrete Tenement
- Industrial Frame
- Timber Frame
- Container Stack
- Vertical Core / Tree

Every preset produces stable IDs, support relationships, level metadata, build-zone sockets, bridge/wall/roof/support sockets, a reachable primary-circulation graph, protected headroom volumes, a JSON manifest, and a validation report.

## Install

Install the ZIP from Blender's **Edit > Preferences > Add-ons > Install from Disk**, then open **3D View > N Panel > Shantypunk > Host Generator**.

Primary target: Blender 5.1. Best-effort compatibility: Blender 4.5 LTS and Blender 5.2.
