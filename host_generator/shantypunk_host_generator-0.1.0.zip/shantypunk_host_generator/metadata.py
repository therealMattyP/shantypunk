SCHEMA_VERSION = 1
GENERATOR_VERSION = "0.1.0"
ROOT_COLLECTION = "SP_HOST_GENERATOR"
HOST_COLLECTION = "SP_HOST_GEOMETRY"
SOCKET_COLLECTION = "SP_HOST_SOCKETS"
DEBUG_COLLECTION = "SP_HOST_DEBUG"
MANIFEST_TEXT = "SP_HOST_MANIFEST"
VALIDATION_TEXT = "SP_HOST_VALIDATION"

SOCKET_TYPES = {
    "GROUND_ENTRY", "WALK_ANCHOR", "CELL_ATTACH", "BRIDGE_ATTACH",
    "WALL_ATTACH", "ROOF_ATTACH", "SUPPORT_DOWN", "UTILITY_ATTACH",
}


def tag(obj, stable_id, role, host_type, level=0, support_id="", **extra):
    obj["SP_ID"] = stable_id
    obj["SP_ROLE"] = role
    obj["SP_HOST_TYPE"] = host_type
    obj["SP_LEVEL"] = int(level)
    obj["SP_SUPPORT_ID"] = support_id
    obj["SP_SCHEMA_VERSION"] = SCHEMA_VERSION
    obj["SP_GENERATOR_VERSION"] = GENERATOR_VERSION
    for key, value in extra.items():
        obj[key] = value
    return obj
