bl_info = {
    "name": "Shantypunk Host Generator",
    "author": "OpenAI",
    "version": (0, 1, 0),
    "blender": (4, 5, 0),
    "location": "View3D > Sidebar > Shantypunk",
    "description": "Generate validated settlement hosts, sockets, support chains, and reserved circulation",
    "category": "Object",
}

import bpy
from . import properties, ui


def register():
    properties.register()
    ui.register()


def unregister():
    ui.unregister()
    properties.unregister()


if __name__ == "__main__":
    register()
