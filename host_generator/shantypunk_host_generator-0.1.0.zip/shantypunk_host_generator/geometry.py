import bpy
import math
from mathutils import Vector
from . import metadata


MATERIALS = {
    "HOST_CONCRETE": (0.30, 0.32, 0.34, 1.0),
    "HOST_TIMBER": (0.30, 0.13, 0.045, 1.0),
    "HOST_STEEL": (0.08, 0.12, 0.15, 1.0),
    "HOST_CONTAINER": (0.10, 0.30, 0.38, 1.0),
    "HOST_TERRAIN": (0.28, 0.24, 0.18, 1.0),
    "HOST_CORE": (0.24, 0.11, 0.035, 1.0),
    "DEBUG_CLEARANCE": (1.0, 0.04, 0.02, 0.18),
    "DEBUG_BUILDABLE": (0.05, 0.75, 0.22, 0.16),
}


def ensure_collection(name, parent=None):
    collection = bpy.data.collections.get(name) or bpy.data.collections.new(name)
    parent = parent or bpy.context.scene.collection
    if collection.name not in {child.name for child in parent.children}:
        parent.children.link(collection)
    return collection


def remove_collection(name):
    collection = bpy.data.collections.get(name)
    if not collection:
        return
    for child in list(collection.children):
        remove_collection(child.name)
    for obj in list(collection.objects):
        bpy.data.objects.remove(obj, do_unlink=True)
    bpy.data.collections.remove(collection)


def material(name):
    rgba = MATERIALS[name]
    mat = bpy.data.materials.get("SP_" + name) or bpy.data.materials.new("SP_" + name)
    mat.diffuse_color = rgba
    mat.use_nodes = True
    shader = mat.node_tree.nodes.get("Principled BSDF")
    if shader:
        shader.inputs["Base Color"].default_value = rgba
        shader.inputs["Roughness"].default_value = 0.72
        if "Alpha" in shader.inputs:
            shader.inputs["Alpha"].default_value = rgba[3]
    if rgba[3] < 1.0:
        try:
            mat.surface_render_method = 'DITHERED'
        except Exception:
            pass
    return mat


def assign_material(obj, mat):
    if obj.data and hasattr(obj.data, "materials"):
        obj.data.materials.append(mat)


def box(name, minimum, maximum, collection, mat=None, bevel=0.0):
    minimum, maximum = Vector(minimum), Vector(maximum)
    center = (minimum + maximum) * 0.5
    size = maximum - minimum
    bpy.ops.mesh.primitive_cube_add(location=center)
    obj = bpy.context.object
    obj.name = name
    obj.dimensions = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    for owner in list(obj.users_collection):
        owner.objects.unlink(obj)
    collection.objects.link(obj)
    if mat:
        assign_material(obj, mat)
    if bevel > 0:
        modifier = obj.modifiers.new("SP_Host_Bevel", 'BEVEL')
        modifier.width = bevel
        modifier.segments = 2
        modifier.limit_method = 'ANGLE'
    return obj


def polygon_prism(name, points, bottom, top, collection, mat=None):
    count = len(points)
    vertices = [(x, y, bottom) for x, y in points] + [(x, y, top) for x, y in points]
    faces = [tuple(range(count - 1, -1, -1)), tuple(range(count, count * 2))]
    for index in range(count):
        nxt = (index + 1) % count
        faces.append((index, nxt, count + nxt, count + index))
    mesh = bpy.data.meshes.new(name + "_MESH")
    mesh.from_pydata(vertices, [], faces)
    mesh.update()
    obj = bpy.data.objects.new(name, mesh)
    collection.objects.link(obj)
    if mat:
        assign_material(obj, mat)
    modifier = obj.modifiers.new("SP_Host_Bevel", 'BEVEL')
    modifier.width = 0.025
    modifier.segments = 2
    modifier.limit_method = 'ANGLE'
    return obj


def cylinder(name, radius, depth, location, collection, mat=None, vertices=20):
    bpy.ops.mesh.primitive_cylinder_add(vertices=vertices, radius=radius, depth=depth, location=location)
    obj = bpy.context.object
    obj.name = name
    for owner in list(obj.users_collection):
        owner.objects.unlink(obj)
    collection.objects.link(obj)
    if mat:
        assign_material(obj, mat)
    return obj


def empty(name, location, collection, display='PLAIN_AXES', size=0.35):
    obj = bpy.data.objects.new(name, None)
    collection.objects.link(obj)
    obj.location = location
    obj.empty_display_type = display
    obj.empty_display_size = size
    obj.show_in_front = True
    obj.hide_render = True
    return obj


def debug_volume(name, center, dimensions, collection, mat_name, visible=True):
    dims = Vector(dimensions)
    center = Vector(center)
    obj = box(name, center - dims * 0.5, center + dims * 0.5, collection, material(mat_name))
    obj.display_type = 'WIRE'
    obj.show_in_front = True
    obj.hide_render = True
    obj.hide_viewport = not visible
    obj["SP_DEBUG_VOLUME"] = True
    return obj
