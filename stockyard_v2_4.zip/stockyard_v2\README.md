# Stockyard v2.4

Stockyard v2 is the first construction-plausible procedural timber platform prototype for Shantypunk.

## Design rules

- Blender units are treated as meters.
- `Chaos = 0` produces deterministic, square, structurally legible construction.
- Randomness is seeded and belongs only to explicit imperfection controls.
- Generated parts are independent named objects with semantic `stockyard_role` metadata.
- The prototype targets midground visual quality and downstream refinement rather than joinery-level fabrication detail.

## Included structure

- Post grid based on width/depth bay counts
- Primary beams
- Joists at adjustable real-world spacing
- Individual deck boards with adjustable gaps
- Optional diagonal or cross bracing
- Multistory platform generation
- Framed floor openings reserved before posts, beams, joists, and decking
- Straight timber stairs, fixed ladders, perimeter rails, and opening rails
- Attachment sockets for future construction hosts

## Hosted circulation prototype

Version 2.4 attaches the circulation ribbon to simplified multistory shanty volumes. The gray boxes establish the spatial contract that later detailed shanties must preserve: story elevations, building envelopes, access openings, sockets, and conservative clearance zones.

Three host presets are included:

- **Simple Stack** for baseline straight-route tests
- **Setback Stack** for landing and balcony conditions
- **Irregular Stack** for constrained-route tests

Every story receives a door proxy and attachment socket. Each story transition receives persistent start and end access markers in the `STOCKYARD_V2_HOSTS` collection. Move those marker empties in the viewport and generate again to test a custom route. Use **Reset v2.4 Hosts** to return them to their preset positions.

The hosted ribbon provides:

- Persistent, draggable start and end access-point markers
- Straight, L-shaped, and switchback route modes
- Endpoint and turning-landing proxies
- Automatic guardrail gaps at the nearest platform edges
- Adjustable outboard offset, width, landing size, and clearance
- Total horizontal run, vertical rise, and maximum segment slope in the Blender panel
- Automatic interpretation as walkway, ramp, stairs, ship stair, or ladder
- Route metadata on generated objects for later circulation solving
- Diagnostic slope, headroom, and gray-box collision tests stored as route metadata

The ribbon remains intentionally abstract. It is not an accessibility-compliant constructed ramp. Later releases will interpret the validated path as timber stairs, scaffold stairs, fire escapes, ladders, bridges, or other assemblies.

## Explicit chaos controls

- Post lean
- Joist/member shift
- Joist twist
- Deck-board twist
- Deck-board end shift
- Deck-board height variation
- Missing-board probability
- Repair-board count

All chaos values are multiplied by the master `Chaos` slider. At zero, none of these deviations are applied.

## Installation

1. Copy the `stockyard_v2` folder into Blender's add-ons directory, or zip the folder and install it through Blender Preferences.
2. Enable **Shantypunk Stockyard v2**.
3. Open the 3D View sidebar.
4. Select the **Shantypunk** tab.
5. Adjust the controls and click **Generate Stockyard v2**.

The generator replaces the contents of the `STOCKYARD_V2` collection each time it runs.

## Current limitations

- Collision testing currently uses the generated gray-box envelopes; it does not yet solve around arbitrary scene geometry.
- L-shaped and switchback paths use deterministic prototype bends rather than a search-based route solver.
- Guardrail gaps follow the nearest platform edge, while interior framed floor openings remain part of the legacy stair and ladder modes.
- No roof, doors, walls, corrugated panels, or enclosed rooms yet.
- No material assignment or UV generation yet.
- No curve-driven footprint yet.
- Deck-board sag is represented only by per-board displacement/rotation; true curved sag is a later geometry pass.
- Braces are visual structural members and do not yet solve around collisions.

## Recommended next passes

1. Replace deterministic bends with simple obstacle-aware route selection.
2. Interpret validated routes as parameterized timber stairs and landings.
3. Add scaffold bays, scaffold stairs, and scaffold landings.
4. Add bridge and balcony attachment families.
5. Replace one gray-box preset with a representative constructed shanty while preserving the same host contract.
6. Add material slots and deterministic material variation.
7. Add commit/bake workflow and Unreal-friendly export metadata.
