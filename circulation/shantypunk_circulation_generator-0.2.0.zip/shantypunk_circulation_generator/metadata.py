SCHEMA_VERSION = 1
GENERATOR_VERSION = "0.2.0"

ROOT_COLLECTION = "SP_CIRCULATION_GENERATOR"
MANIFEST_TEXT = "SP_CIRCULATION_MANIFEST"
VALIDATION_TEXT = "SP_CIRCULATION_VALIDATION"

NODE_TYPES = {
    "GROUND_ENTRY",
    "LANDING",
    "BUILDING_ACCESS",
    "BRIDGE_PORT",
}


def tag(obj, stable_id, role, instance_id, host_id, level=0, **extra):
    obj["SP_ID"] = stable_id
    obj["SP_ROLE"] = role
    obj["SP_INSTANCE_ID"] = instance_id
    obj["SP_SOURCE_HOST_ID"] = host_id
    obj["SP_LEVEL"] = int(level)
    obj["SP_SCHEMA_VERSION"] = SCHEMA_VERSION
    obj["SP_GENERATOR_VERSION"] = GENERATOR_VERSION
    for key, value in extra.items():
        obj[key] = value
    return obj
