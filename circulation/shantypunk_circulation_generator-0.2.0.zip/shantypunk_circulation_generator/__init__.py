bl_info = {
    "name": "Shantypunk Circulation Generator",
    "author": "OpenAI",
    "version": (0, 2, 0),
    "blender": (4, 5, 0),
    "location": "View3D > Sidebar > Shantypunk",
    "description": "Generate controller-based circulation from Shantypunk hosts",
    "category": "Object",
}

from . import properties, ui


def register():
    properties.register()
    ui.register()


def unregister():
    ui.unregister()
    properties.unregister()


if __name__ == "__main__":
    register()
