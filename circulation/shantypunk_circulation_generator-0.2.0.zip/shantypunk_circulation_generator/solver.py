import hashlib
import json
import math
import random

import bpy
from mathutils import Vector

from . import geometry as geo, metadata, properties, validation


def circulation_controller_from_object(obj):
    while obj:
        if obj.get("SP_ROLE") == "CIRCULATION_CONTROLLER":
            return obj
        obj = obj.parent
    return None


def host_controller_from_object(obj):
    circulation = circulation_controller_from_object(obj)
    if circulation:
        obj = circulation.parent
    while obj:
        if obj.get("SP_ROLE") == "HOST_CONTROLLER":
            return obj
        obj = obj.parent
    return None


def circulation_for_host(host_controller):
    if not host_controller:
        return None
    for child in host_controller.children:
        if child.get("SP_ROLE") == "CIRCULATION_CONTROLLER":
            return child
    return None


def source_sockets(host_controller, socket_type=None):
    sockets = [
        obj for obj in host_controller.children
        if obj.get("SP_ROLE") == "SOCKET" and obj.get("SP_SOCKET_TYPE")
    ]
    if socket_type:
        sockets = [obj for obj in sockets if obj.get("SP_SOCKET_TYPE") == socket_type]
    return sockets


def source_signature(host_controller):
    records = []
    for obj in source_sockets(host_controller):
        records.append({
            "id": obj.get("SP_ID"),
            "type": obj.get("SP_SOCKET_TYPE"),
            "level": obj.get("SP_LEVEL", 0),
            "location": [round(value, 5) for value in obj.location],
        })
    payload = json.dumps({
        "host_type": host_controller.get("SP_HOST_TYPE", ""),
        "host_generator_version": host_controller.get("SP_GENERATOR_VERSION", ""),
        "sockets": sorted(records, key=lambda item: item["id"]),
    }, sort_keys=True)
    return hashlib.sha1(payload.encode("utf-8")).hexdigest()


def next_instance_id():
    used = {
        obj.get("SP_INSTANCE_ID") for obj in bpy.data.objects
        if obj.get("SP_ROLE") == "CIRCULATION_CONTROLLER"
    }
    index = 1
    while "C%04d" % index in used:
        index += 1
    return "C%04d" % index


def instance_collection_name(instance_id):
    return "SP_CIRCULATION_%s" % instance_id


def create_controller(context, host_controller):
    root = geo.ensure_collection(metadata.ROOT_COLLECTION)
    instance_id = next_instance_id()
    collection = geo.ensure_collection(instance_collection_name(instance_id), root)
    name = "SPC_%s_CONTROLLER" % instance_id
    controller = geo.empty(name, (0.0, 0.0, 0.0), collection, 'CUBE', 0.62)
    controller.parent = host_controller
    controller.location = (0.0, 0.0, 0.0)
    metadata.tag(
        controller, name, "CIRCULATION_CONTROLLER", instance_id,
        host_controller.get("SP_INSTANCE_ID", host_controller.name),
        SP_INSTANCE_COLLECTION=collection.name,
        SP_SOURCE_HOST_CONTROLLER=host_controller.name,
    )
    properties.copy_settings(context.scene.sp_circulation_settings,
                             controller.sp_circulation_settings)
    return controller, collection


def remove_owned_modifiers(controller):
    prefix = "SPC_%s_OPENING_" % controller.get("SP_INSTANCE_ID", "")
    for obj in bpy.data.objects:
        for modifier in list(obj.modifiers):
            if modifier.name.startswith(prefix):
                obj.modifiers.remove(modifier)


def clear_generated(controller):
    instance_id = controller.get("SP_INSTANCE_ID")
    remove_owned_modifiers(controller)
    for suffix in ("_GEOMETRY", "_NODES", "_DEBUG", "_CUTTERS"):
        geo.remove_collection("SP_CIRCULATION_%s%s" % (instance_id, suffix))


class BuildContext:
    def __init__(self, settings, controller, host_controller, instance_collection):
        self.s = settings
        self.controller = controller
        self.host_controller = host_controller
        self.instance_id = controller["SP_INSTANCE_ID"]
        self.host_id = host_controller.get("SP_INSTANCE_ID", host_controller.name)
        self.rng = random.Random(settings.seed)
        prefix = "SP_CIRCULATION_%s" % self.instance_id
        self.geometry = geo.ensure_collection(prefix + "_GEOMETRY", instance_collection)
        self.nodes_collection = geo.ensure_collection(prefix + "_NODES", instance_collection)
        self.debug = geo.ensure_collection(prefix + "_DEBUG", instance_collection)
        self.cutters = geo.ensure_collection(prefix + "_CUTTERS", instance_collection)
        self.objects = []
        self.nodes = []
        self.edges = []
        self.segments = []
        self.exclusions = []
        self.opening_reservations = []
        self.access_contracts = []
        self.no_rail_edges = []
        self.bridge_reservations = []
        self.object_index = 0

    def stable_id(self, local_id):
        return "SPC_%s_%s" % (self.instance_id, local_id)

    def register(self, obj, local_id, role, level=0, **extra):
        stable_id = self.stable_id(local_id)
        obj.name = stable_id
        obj.parent = self.controller
        metadata.tag(obj, stable_id, role, self.instance_id, self.host_id, level,
                     SP_LOCAL_ID=local_id, **extra)
        self.objects.append(obj)
        return obj

    def component(self, obj, role, level, prefix, **extra):
        self.object_index += 1
        return self.register(obj, "%s_%04d" % (prefix, self.object_index), role, level, **extra)

    def node(self, local_id, node_type, location, level, source_socket="", **extra):
        obj = geo.empty(self.stable_id(local_id), location, self.nodes_collection,
                        'CUBE' if node_type == "BUILDING_ACCESS" else 'ARROWS', 0.28)
        self.register(obj, local_id, "CIRCULATION_NODE", level,
                      SP_NODE_TYPE=node_type, SP_SOURCE_SOCKET=source_socket, **extra)
        self.nodes.append(obj["SP_ID"])
        return obj

    def edge(self, start_node, end_node, edge_type, level_from, level_to):
        self.edges.append({
            "from": start_node["SP_ID"] if hasattr(start_node, "get") else start_node,
            "to": end_node["SP_ID"] if hasattr(end_node, "get") else end_node,
            "type": edge_type,
            "level_from": int(level_from),
            "level_to": int(level_to),
        })


def construction_style(settings, host_controller):
    if settings.stair_material != 'AUTO':
        return settings.stair_material
    host_type = host_controller.get("SP_HOST_TYPE", "")
    if host_type in {"TERRACED_HILLSIDE", "CONCRETE_TENEMENT"}:
        return "CONCRETE"
    if host_type in {"TIMBER_FRAME", "VERTICAL_CORE"}:
        return "TIMBER"
    return "STEEL"


def host_half_width(host_controller):
    extent = 0.0
    for obj in host_controller.children:
        if obj.type != 'MESH' or obj.get("SP_ROLE") in {"SOCKET", "CLEARANCE", "BUILD_ZONE"}:
            continue
        for corner in obj.bound_box:
            point = obj.matrix_local @ Vector(corner)
            extent = max(extent, abs(point.x))
    return extent


def primary_route_position(ctx, anchor):
    position = anchor.location.copy()
    if ctx.host_controller.get("SP_HOST_TYPE") == "TERRACED_HILLSIDE":
        position.x = host_half_width(ctx.host_controller) + ctx.s.route_width * 0.70
    return position


def host_surface_supports(ctx, point, tolerance=0.35):
    point = Vector(point)
    for obj in ctx.host_controller.children:
        if obj.type != 'MESH' or obj.get("SP_ROLE") in {"CLEARANCE", "BUILD_ZONE"}:
            continue
        corners = [obj.matrix_local @ Vector(corner) for corner in obj.bound_box]
        minimum = Vector((min(p.x for p in corners), min(p.y for p in corners), min(p.z for p in corners)))
        maximum = Vector((max(p.x for p in corners), max(p.y for p in corners), max(p.z for p in corners)))
        if (minimum.x - 0.02 <= point.x <= maximum.x + 0.02 and
                minimum.y - 0.02 <= point.y <= maximum.y + 0.02 and
                abs(maximum.z - point.z) <= tolerance):
            return True
    return False


def exposed_rail_sides(ctx, start, end, width, force=False):
    if not ctx.s.generate_guardrails or ctx.s.railing_mode == 'NONE':
        return []
    if force or ctx.s.railing_mode == 'ALL':
        return [-1.0, 1.0]
    start, end = Vector(start), Vector(end)
    horizontal = Vector((end.x - start.x, end.y - start.y, 0.0))
    if horizontal.length < 0.10:
        return []
    direction = horizontal.normalized()
    perpendicular = Vector((-direction.y, direction.x, 0.0))
    midpoint = start.lerp(end, 0.5)
    sides = []
    for side in (-1.0, 1.0):
        sample = midpoint + perpendicular * side * width * 0.62
        if not host_surface_supports(ctx, sample):
            sides.append(side)
    return sides


def bounds_contract(center, dimensions):
    center, dimensions = Vector(center), Vector(dimensions)
    half = dimensions * 0.5
    return {
        "center": list(center),
        "dimensions": list(dimensions),
        "min": list(center - half),
        "max": list(center + half),
    }


def target_platforms(ctx, level):
    roles = {"HOST_PLATFORM", "RADIAL_PLATFORM"}
    return [
        obj for obj in ctx.host_controller.children
        if obj.type == 'MESH' and obj.get("SP_ROLE") in roles and int(obj.get("SP_LEVEL", -1)) == int(level)
    ]


def add_opening_reservation(ctx, level, start, end, top_z, suffix):
    if not ctx.s.cut_platform_openings:
        return None
    targets = target_platforms(ctx, level)
    if not targets:
        return None
    start, end = Vector(start), Vector(end)
    horizontal = Vector((end.x - start.x, end.y - start.y, 0.0))
    length = horizontal.length
    if length < 0.10:
        length = ctx.s.landing_depth
        horizontal = Vector((1.0, 0.0, 0.0))
    direction = horizontal.normalized()
    center = (start + end) * 0.5
    center.z = top_z
    dimensions = Vector((length + ctx.s.opening_margin * 2.0,
                         ctx.s.stair_width + ctx.s.opening_margin * 2.0,
                         max(0.80, ctx.s.platform_thickness * 4.0)))
    angle = math.atan2(direction.y, direction.x)
    cutter = geo.box("opening_cutter", center, dimensions, ctx.cutters,
                     geo.material("DEBUG_CLEARANCE"), angle)
    cutter.display_type = 'WIRE'
    cutter.show_in_front = True
    cutter.hide_render = True
    cutter.hide_viewport = not ctx.s.show_opening_cutters
    ctx.component(cutter, "OPENING_RESERVATION", level, "OPENING_%s" % suffix,
                  SP_NON_EXPORT=True)
    record = {
        "id": cutter["SP_ID"],
        "level": int(level),
        "targets": [obj.get("SP_ID", obj.name) for obj in targets],
        "start": list(start),
        "end": list(end),
        "orientation_z": angle,
        **bounds_contract(center, dimensions),
    }
    ctx.opening_reservations.append(record)
    for index, target in enumerate(targets):
        modifier = target.modifiers.new(
            "SPC_%s_OPENING_%s_%d" % (ctx.instance_id, suffix, index), 'BOOLEAN')
        modifier.operation = 'DIFFERENCE'
        try:
            modifier.solver = 'EXACT'
        except Exception:
            pass
        modifier.object = cutter
    return cutter


def add_guardrails(ctx, start, end, width, level, suffix, material, force=False):
    start, end = Vector(start), Vector(end)
    horizontal = Vector((end.x - start.x, end.y - start.y, 0.0))
    length = horizontal.length
    if length < 0.30:
        return
    direction = horizontal.normalized()
    perpendicular = Vector((-direction.y, direction.x, 0.0))
    count = max(1, int(math.ceil(length / ctx.s.rail_spacing)))
    sides = exposed_rail_sides(ctx, start, end, width, force)
    omitted = [side for side in (-1.0, 1.0) if side not in sides]
    for side in omitted:
        ctx.no_rail_edges.append({
            "route": suffix,
            "level": int(level),
            "side": "LEFT" if side < 0 else "RIGHT",
            "reason": "SUPPORTED_OR_CONNECTED_EDGE",
            "start": list(start),
            "end": list(end),
        })
    for side_index, side in enumerate(sides):
        parts = []
        offset = perpendicular * side * width * 0.48
        rail_start = start + offset + Vector((0.0, 0.0, ctx.s.rail_height))
        rail_end = end + offset + Vector((0.0, 0.0, ctx.s.rail_height))
        rail = geo.cylinder_between(
            "rail", rail_start, rail_end, 0.025, ctx.geometry, material, 8)
        if rail:
            parts.append(rail)
        for post_index in range(count + 1):
            factor = post_index / count
            base = start.lerp(end, factor) + offset
            post = geo.cylinder_between(
                "post", base, base + Vector((0.0, 0.0, ctx.s.rail_height)),
                0.022, ctx.geometry, material, 8)
            if post:
                parts.append(post)
        assembly = geo.join_objects(parts, "guardrail_assembly", ctx.geometry)
        if assembly:
            ctx.component(
                assembly, "GUARDRAIL_ASSEMBLY", level,
                "RAIL_%s_%d" % (suffix, side_index),
                SP_COMPONENT_COUNT=len(parts),
                SP_RAIL_SIDE="LEFT" if side < 0 else "RIGHT")


def add_clearance(ctx, start, end, level, suffix):
    start, end = Vector(start), Vector(end)
    obj = geo.clearance_between(
        "clearance", start, end, ctx.s.route_width, ctx.s.headroom,
        ctx.debug, ctx.s.show_clearance)
    if obj:
        ctx.component(obj, "CLEARANCE", level, "CLEARANCE_%s" % suffix,
                      SP_NON_EXPORT=True)
        horizontal = Vector((end.x - start.x, end.y - start.y, 0.0))
        length = max(horizontal.length, ctx.s.route_width)
        center = start.lerp(end, 0.5) + Vector((0.0, 0.0, ctx.s.headroom * 0.5))
        dimensions = (length, ctx.s.route_width, ctx.s.headroom + abs(end.z - start.z))
        ctx.exclusions.append({
            "id": obj["SP_ID"],
            "type": "CIRCULATION_CLEARANCE",
            "level": int(level),
            "route": suffix,
            "start": list(start),
            "end": list(end),
            "width": ctx.s.route_width,
            "height": ctx.s.headroom,
            "orientation_z": math.atan2(horizontal.y, horizontal.x) if horizontal.length else 0.0,
            **bounds_contract(center, dimensions),
        })


def add_landing(ctx, location, level, suffix, material):
    location = Vector(location)
    center = location - Vector((0.0, 0.0, ctx.s.platform_thickness * 0.5))
    obj = geo.box(
        "landing", center,
        (ctx.s.route_width, ctx.s.landing_depth, ctx.s.platform_thickness),
        ctx.geometry, material, bevel=0.015)
    ctx.component(obj, "LANDING_PLATFORM", level, "LANDING_%s" % suffix)
    return obj


def add_walkway(ctx, start, end, level, suffix, material, guardrails=True, role="WALKWAY"):
    start, end = Vector(start), Vector(end)
    horizontal_length = Vector((end.x - start.x, end.y - start.y, 0.0)).length
    if horizontal_length < 0.08:
        return None
    slab = geo.slab_between(
        "walkway", start, end, ctx.s.route_width, ctx.s.platform_thickness,
        ctx.geometry, material, 0.012)
    ctx.component(slab, role, level, "ROUTE_%s" % suffix)
    if guardrails:
        add_guardrails(ctx, start, end, ctx.s.route_width, level, suffix, material)
    add_clearance(ctx, start, end, level, suffix)
    ctx.segments.append({
        "type": role,
        "level": int(level),
        "start": list(start),
        "end": list(end),
    })
    return slab


def add_framed_stringers(ctx, start, end, direction, material, level, suffix):
    perpendicular = Vector((-direction.y, direction.x, 0.0))
    parts = []
    for side_index, side in enumerate((-1.0, 1.0)):
        offset = perpendicular * side * ctx.s.stair_width * 0.38
        beam = geo.beam_between(
            "stringer", start + offset - Vector((0.0, 0.0, 0.12)),
            end + offset - Vector((0.0, 0.0, 0.12)), 0.12,
            ctx.geometry, material)
        if beam:
            parts.append(beam)
    return parts


def add_stair_flight(ctx, start, target, level, transition_index, style, material):
    start, target = Vector(start), Vector(target)
    rise = target.z - start.z
    if rise <= 0.03:
        add_walkway(ctx, start, target, level, "LEVEL_%02d" % level, material)
        return target, "WALKWAY"
    horizontal = Vector((target.x - start.x, target.y - start.y, 0.0))
    if (horizontal.length < ctx.s.stair_width * 1.15 and
            ctx.s.vertical_fallback == 'LADDER'):
        return add_ladder(ctx, start, target, level, transition_index, material), "LADDER"
    step_count = max(2, int(math.ceil(rise / ctx.s.target_riser)))
    riser = rise / step_count
    run = step_count * ctx.s.tread_depth
    if horizontal.length >= ctx.s.stair_width * 1.15:
        direction = horizontal.normalized()
    else:
        direction = Vector((1.0 if transition_index % 2 == 0 else -1.0, 0.0, 0.0))
    flight_end = Vector((start.x + direction.x * run, start.y + direction.y * run, target.z))
    suffix = "L%02d" % level
    stair_parts = []
    for index in range(step_count):
        tread_center = start + direction * ((index + 0.5) * ctx.s.tread_depth)
        tread_top = start.z + (index + 1) * riser
        if style == "CONCRETE":
            height = tread_top - start.z + ctx.s.platform_thickness
            center_z = start.z - ctx.s.platform_thickness + height * 0.5
        else:
            height = 0.09
            center_z = tread_top - height * 0.5
        tread_center.z = center_z
        angle = math.atan2(direction.y, direction.x)
        tread = geo.box(
            "tread", tread_center,
            (ctx.s.tread_depth * 1.02, ctx.s.stair_width, height),
            ctx.geometry, material, angle, 0.0)
        stair_parts.append(tread)
    if style != "CONCRETE":
        stair_parts.extend(add_framed_stringers(
            ctx, start, flight_end, direction, material, level, suffix))
    assembly = geo.join_objects(stair_parts, "stair_assembly", ctx.geometry)
    if assembly:
        ctx.component(
            assembly, "STAIR_ASSEMBLY", level, "STAIR_%s" % suffix,
            SP_STEP_COUNT=step_count, SP_CONSTRUCTION_STYLE=style,
            SP_COMPONENT_COUNT=len(stair_parts))
    add_guardrails(
        ctx, start, flight_end, ctx.s.stair_width, level, suffix, material,
        force=True)
    add_clearance(ctx, start, flight_end, level, "STAIR_%s" % suffix)
    ctx.segments.append({
        "type": "STAIR",
        "style": style,
        "level": int(level),
        "step_count": step_count,
        "riser": riser,
        "tread": ctx.s.tread_depth,
        "start": list(start),
        "end": list(flight_end),
    })
    opening_run = min(run, (ctx.s.headroom / rise) * run + ctx.s.opening_margin)
    opening_start = flight_end - direction * opening_run
    opening_start.z = target.z
    add_opening_reservation(
        ctx, level, opening_start, flight_end, target.z,
        "STAIR_L%02d" % level)
    add_landing(ctx, flight_end, level, "FLIGHT_TOP_%02d" % level, material)
    add_walkway(ctx, flight_end, target, level, "TOP_CONNECT_%02d" % level,
                material, guardrails=True, role="LANDING_CONNECTOR")
    return target, "STAIR"


def add_ladder(ctx, start, target, level, transition_index, material):
    start, target = Vector(start), Vector(target)
    direction = Vector((1.0 if transition_index % 2 == 0 else -1.0, 0.0, 0.0))
    ladder_base = start + direction * ctx.s.landing_depth * 0.45
    ladder_top = Vector((ladder_base.x, ladder_base.y, target.z))
    perpendicular = Vector((-direction.y, direction.x, 0.0))
    half_width = min(0.30, ctx.s.stair_width * 0.28)
    ladder_parts = []
    for side_index, side in enumerate((-1.0, 1.0)):
        offset = perpendicular * side * half_width
        rail = geo.cylinder_between(
            "ladder_rail", ladder_base + offset, ladder_top + offset,
            0.025, ctx.geometry, material, 8)
        if rail:
            ladder_parts.append(rail)
    rung_count = max(2, int(math.floor((target.z - start.z) / 0.30)))
    for index in range(rung_count + 1):
        z = start.z + (target.z - start.z) * (index / rung_count)
        center = Vector((ladder_base.x, ladder_base.y, z))
        rung = geo.cylinder_between(
            "ladder_rung", center - perpendicular * half_width,
            center + perpendicular * half_width, 0.018, ctx.geometry, material, 8)
        if rung:
            ladder_parts.append(rung)
    assembly = geo.join_objects(ladder_parts, "ladder_assembly", ctx.geometry)
    if assembly:
        ctx.component(
            assembly, "LADDER_ASSEMBLY", level, "LADDER_%02d" % level,
            SP_COMPONENT_COUNT=len(ladder_parts), SP_RUNG_COUNT=rung_count + 1)
    opening_start = ladder_top - direction * (ctx.s.stair_width * 0.5)
    opening_end = ladder_top + direction * (ctx.s.stair_width * 0.5)
    add_opening_reservation(
        ctx, level, opening_start, opening_end, target.z,
        "LADDER_L%02d" % level)
    add_landing(ctx, ladder_top, level, "LADDER_TOP_%02d" % level, material)
    add_walkway(ctx, ladder_top, target, level, "LADDER_CONNECT_%02d" % level,
                material, guardrails=True, role="LANDING_CONNECTOR")
    ctx.segments.append({
        "type": "LADDER",
        "level": int(level),
        "start": list(ladder_base),
        "end": list(ladder_top),
    })
    return target


def solve(ctx):
    grounds = source_sockets(ctx.host_controller, "GROUND_ENTRY")
    anchors = sorted(
        source_sockets(ctx.host_controller, "WALK_ANCHOR"),
        key=lambda obj: (obj.get("SP_LEVEL", 0), obj.name))
    if not grounds or not anchors:
        raise ValueError("The selected host needs a ground entry and walk anchors")
    style = construction_style(ctx.s, ctx.host_controller)
    material = geo.material(style)
    access_material = geo.material("ACCESS")
    ground = grounds[0]
    ground_pos = ground.location.copy()
    entry_node = ctx.node("GROUND_ENTRY", "GROUND_ENTRY", ground_pos, 0, ground.get("SP_ID", ""))
    add_landing(ctx, ground_pos, 0, "GROUND", material)
    landing_nodes = {}
    anchor_positions = {}
    previous_node = entry_node
    previous_position = ground_pos
    previous_level = 0
    for transition_index, anchor in enumerate(anchors):
        level = int(anchor.get("SP_LEVEL", transition_index))
        anchor_position = anchor.location.copy()
        position = primary_route_position(ctx, anchor)
        landing = ctx.node(
            "LANDING_L%02d" % level, "LANDING", position, level,
            anchor.get("SP_ID", ""))
        landing_nodes[level] = landing
        anchor_positions[level] = anchor_position
        add_landing(ctx, position, level, "ANCHOR_%02d" % level, material)
        if level == 0:
            add_walkway(
                ctx, previous_position, position, 0, "ENTRY", material,
                guardrails=False)
            edge_type = "WALKWAY"
        else:
            _end, edge_type = add_stair_flight(
                ctx, previous_position, position, level, transition_index,
                style, material)
        ctx.edge(previous_node, landing, edge_type, previous_level, level)
        if (position - anchor_position).length > 0.08:
            add_walkway(
                ctx, position, anchor_position, level,
                "HOST_CONNECT_%02d" % level, material,
                guardrails=True, role="HOST_ANCHOR_CONNECTOR")
        previous_node = landing
        previous_position = position
        previous_level = level
    if ctx.s.connect_cell_zones:
        cells = sorted(source_sockets(ctx.host_controller, "CELL_ATTACH"), key=lambda obj: obj.name)
        for index, cell in enumerate(cells):
            level = int(cell.get("SP_LEVEL", 0))
            landing = landing_nodes.get(level)
            if not landing:
                continue
            position = cell.location.copy()
            route_position = anchor_positions[level]
            toward_route = Vector((route_position.x - position.x,
                                   route_position.y - position.y, 0.0))
            if toward_route.length < 1e-5:
                toward_route = Vector((0.0, -1.0, 0.0))
            toward_route.normalize()
            outward = -toward_route
            footprint = list(cell.get("SP_FOOTPRINT", (0.0, 0.0, 0.0)))
            frontage_width = float(footprint[1] if len(footprint) > 1 and footprint[1] else ctx.s.route_width)
            apron_depth = max(ctx.s.landing_depth, ctx.s.route_width)
            build_side = "LEFT" if position.x < route_position.x else "RIGHT"
            node = ctx.node(
                "ACCESS_%03d" % index, "BUILDING_ACCESS", position, level,
                cell.get("SP_ID", ""),
                SP_ACCESS_DIRECTION=list(toward_route),
                SP_OUTWARD_DIRECTION=list(outward),
                SP_FRONTAGE_WIDTH=frontage_width,
                SP_APRON_DEPTH=apron_depth,
                SP_BUILD_SIDE=build_side)
            add_walkway(
                ctx, route_position, position, level,
                "ACCESS_%03d" % index, access_material,
                guardrails=False, role="ACCESS_BRANCH")
            ctx.edge(landing, node, "ACCESS_BRANCH", level, level)
            apron_center = position + toward_route * (apron_depth * 0.5)
            apron_dimensions = (apron_depth, min(frontage_width, ctx.s.route_width * 1.5), ctx.s.headroom)
            access_contract = {
                "source_socket": cell.get("SP_ID", ""),
                "node_id": node["SP_ID"],
                "level": level,
                "location": list(position),
                "entrance_direction": list(toward_route),
                "outward_direction": list(outward),
                "depth_direction": list(outward),
                "frontage_width": frontage_width,
                "apron_depth": apron_depth,
                "build_side": build_side,
                "source_footprint": footprint,
                "apron_bounds": bounds_contract(apron_center, apron_dimensions),
            }
            ctx.access_contracts.append(access_contract)
            ctx.exclusions.append({
                "id": node["SP_ID"] + "_APRON",
                "type": "ACCESS_APRON",
                "level": level,
                **bounds_contract(apron_center, apron_dimensions),
            })
            ctx.no_rail_edges.append({
                "route": "ACCESS_%03d" % index,
                "level": level,
                "side": "CONNECTION",
                "reason": "BUILDING_ENTRANCE",
                "center": list(position),
                "width": min(frontage_width, ctx.s.route_width),
            })
    if ctx.s.expose_bridge_ports:
        bridges = sorted(source_sockets(ctx.host_controller, "BRIDGE_ATTACH"), key=lambda obj: obj.name)
        for index, bridge in enumerate(bridges):
            level = int(bridge.get("SP_LEVEL", 0))
            landing = landing_nodes.get(level)
            node = ctx.node(
                "BRIDGE_PORT_%03d" % index, "BRIDGE_PORT", bridge.location.copy(), level,
                bridge.get("SP_ID", ""), SP_GUARD_STATE="TEMPORARY_UNTIL_CONNECTED")
            if landing:
                ctx.edge(landing, node, "BRIDGE_RESERVATION", level, level)
            ctx.bridge_reservations.append({
                "source_socket": bridge.get("SP_ID", ""),
                "node_id": node["SP_ID"],
                "level": level,
                "location": list(bridge.location),
                "direction": list(bridge.get("SP_SOCKET_DIRECTION", (0.0, 0.0, 0.0))),
                "guard_state": "TEMPORARY_UNTIL_CONNECTED",
            })
    return style


def generate(context, host_controller=None, controller=None):
    if controller:
        host_controller = host_controller_from_object(controller)
        if not host_controller:
            raise ValueError("The circulation controller is no longer attached to a host")
        collection = bpy.data.collections.get(controller.get("SP_INSTANCE_COLLECTION", ""))
        if not collection:
            root = geo.ensure_collection(metadata.ROOT_COLLECTION)
            collection = geo.ensure_collection(instance_collection_name(controller["SP_INSTANCE_ID"]), root)
            controller["SP_INSTANCE_COLLECTION"] = collection.name
            if controller.name not in collection.objects:
                collection.objects.link(controller)
        clear_generated(controller)
    else:
        if not host_controller:
            raise ValueError("Select a Shantypunk Host Controller")
        existing = circulation_for_host(host_controller)
        if existing:
            controller = existing
            collection = bpy.data.collections.get(controller.get("SP_INSTANCE_COLLECTION", ""))
            clear_generated(controller)
        else:
            controller, collection = create_controller(context, host_controller)
    settings = controller.sp_circulation_settings
    ctx = BuildContext(settings, controller, host_controller, collection)
    style = solve(ctx)
    signature = source_signature(host_controller)
    manifest = {
        "schema_version": metadata.SCHEMA_VERSION,
        "generator_version": metadata.GENERATOR_VERSION,
        "instance_id": ctx.instance_id,
        "controller": controller.name,
        "source_host_id": ctx.host_id,
        "source_host_controller": host_controller.name,
        "source_signature": signature,
        "construction_style": style,
        "nodes": [
            {
                "id": obj["SP_ID"],
                "type": obj["SP_NODE_TYPE"],
                "level": obj["SP_LEVEL"],
                "location": list(obj.location),
                "source_socket": obj.get("SP_SOURCE_SOCKET", ""),
                "access_direction": list(obj.get("SP_ACCESS_DIRECTION", ())),
                "outward_direction": list(obj.get("SP_OUTWARD_DIRECTION", ())),
                "frontage_width": obj.get("SP_FRONTAGE_WIDTH", 0.0),
                "apron_depth": obj.get("SP_APRON_DEPTH", 0.0),
                "build_side": obj.get("SP_BUILD_SIDE", ""),
            }
            for obj in ctx.objects if obj.get("SP_ROLE") == "CIRCULATION_NODE"
        ],
        "edges": ctx.edges,
        "segments": ctx.segments,
        "exclusions": ctx.exclusions,
        "opening_reservations": ctx.opening_reservations,
        "access_contracts": ctx.access_contracts,
        "no_rail_edges": ctx.no_rail_edges,
        "bridge_reservations": ctx.bridge_reservations,
        "contracts": {
            "contract_version": 2,
            "route_width": settings.route_width,
            "stair_width": settings.stair_width,
            "target_riser": settings.target_riser,
            "tread_depth": settings.tread_depth,
            "headroom": settings.headroom,
            "opening_margin": settings.opening_margin,
            "coordinate_space": "HOST_LOCAL",
        },
    }
    report = validation.validate(controller, host_controller, manifest)
    manifest["validation"] = report["summary"]
    manifest_name = "%s_%s" % (metadata.MANIFEST_TEXT, ctx.instance_id)
    validation_name = "%s_%s" % (metadata.VALIDATION_TEXT, ctx.instance_id)
    text = bpy.data.texts.get(manifest_name) or bpy.data.texts.new(manifest_name)
    text.clear()
    text.write(json.dumps(manifest, indent=2))
    validation.write_report(report, validation_name)
    controller["SP_MANIFEST_TEXT"] = manifest_name
    controller["SP_VALIDATION_TEXT"] = validation_name
    controller["SP_SOURCE_SIGNATURE"] = signature
    controller["SP_CIRCULATION_VALID"] = report["summary"]["ERROR"] == 0
    controller["SP_CONSTRUCTION_STYLE"] = style
    bpy.ops.object.select_all(action='DESELECT')
    controller.select_set(True)
    context.view_layer.objects.active = controller
    return manifest, report, controller


def validate_controller(controller):
    host_controller = host_controller_from_object(controller)
    text = bpy.data.texts.get(controller.get("SP_MANIFEST_TEXT", "")) if controller else None
    if not host_controller or not text:
        return None
    manifest = json.loads(text.as_string())
    report = validation.validate(controller, host_controller, manifest)
    validation.write_report(
        report, controller.get("SP_VALIDATION_TEXT", metadata.VALIDATION_TEXT))
    controller["SP_CIRCULATION_VALID"] = report["summary"]["ERROR"] == 0
    return report


def delete_circulation(controller):
    if not controller:
        return False
    collection_name = controller.get("SP_INSTANCE_COLLECTION")
    manifest_name = controller.get("SP_MANIFEST_TEXT")
    validation_name = controller.get("SP_VALIDATION_TEXT")
    remove_owned_modifiers(controller)
    if collection_name:
        geo.remove_collection(collection_name)
    else:
        bpy.data.objects.remove(controller, do_unlink=True)
    for name in (manifest_name, validation_name):
        text = bpy.data.texts.get(name) if name else None
        if text:
            bpy.data.texts.remove(text)
    return True
