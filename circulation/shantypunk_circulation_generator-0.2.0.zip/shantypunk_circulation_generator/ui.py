import bpy
from bpy.types import Operator, Panel

from . import solver


def selected_host(context):
    return solver.host_controller_from_object(context.active_object)


def selected_circulation(context):
    direct = solver.circulation_controller_from_object(context.active_object)
    if direct:
        return direct
    return solver.circulation_for_host(selected_host(context))


def report_result(operator, manifest, report, verb):
    errors = report["summary"]["ERROR"]
    if errors:
        operator.report({'WARNING'}, "%s with %d validation errors" % (verb, errors))
    else:
        operator.report(
            {'INFO'}, "%s validated %s circulation" % (
                verb, manifest["construction_style"].title()))


class SPCIRC_OT_generate(Operator):
    bl_idname = "spcirc.generate"
    bl_label = "Generate Circulation"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return selected_host(context) is not None

    def execute(self, context):
        host = selected_host(context)
        try:
            manifest, report, _controller = solver.generate(context, host_controller=host)
        except ValueError as error:
            self.report({'ERROR'}, str(error))
            return {'CANCELLED'}
        report_result(self, manifest, report, "Generated")
        return {'FINISHED'}


class SPCIRC_OT_update(Operator):
    bl_idname = "spcirc.update"
    bl_label = "Update Circulation"
    bl_description = "Rebuild circulation from its settings and the current host sockets"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return selected_circulation(context) is not None

    def execute(self, context):
        controller = selected_circulation(context)
        try:
            manifest, report, _controller = solver.generate(context, controller=controller)
        except ValueError as error:
            self.report({'ERROR'}, str(error))
            return {'CANCELLED'}
        report_result(self, manifest, report, "Updated")
        return {'FINISHED'}


class SPCIRC_OT_validate(Operator):
    bl_idname = "spcirc.validate"
    bl_label = "Validate Circulation"

    @classmethod
    def poll(cls, context):
        return selected_circulation(context) is not None

    def execute(self, context):
        report = solver.validate_controller(selected_circulation(context))
        if report is None:
            self.report({'ERROR'}, "Circulation has no readable source host or manifest")
            return {'CANCELLED'}
        self.report(
            {'INFO' if not report['summary']['ERROR'] else 'WARNING'},
            "%d errors, %d warnings" % (
                report['summary']['ERROR'], report['summary']['WARNING']))
        return {'FINISHED'}


class SPCIRC_OT_delete(Operator):
    bl_idname = "spcirc.delete"
    bl_label = "Delete Circulation"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return selected_circulation(context) is not None

    def execute(self, context):
        solver.delete_circulation(selected_circulation(context))
        self.report({'INFO'}, "Deleted circulation; source host was preserved")
        return {'FINISHED'}


def draw_settings(layout, settings):
    row = layout.row(align=True)
    row.prop(settings, "route_width")
    row.prop(settings, "stair_width")
    layout.prop(settings, "stair_material")
    box = layout.box()
    box.label(text="Stair Geometry")
    row = box.row(align=True)
    row.prop(settings, "target_riser")
    row.prop(settings, "tread_depth")
    box.prop(settings, "landing_depth")
    box.prop(settings, "vertical_fallback")
    box = layout.box()
    box.label(text="Safety and Access")
    box.prop(settings, "headroom")
    box.prop(settings, "generate_guardrails")
    if settings.generate_guardrails:
        box.prop(settings, "railing_mode")
        row = box.row(align=True)
        row.prop(settings, "rail_height")
        row.prop(settings, "rail_spacing")
    box.prop(settings, "connect_cell_zones")
    box.prop(settings, "expose_bridge_ports")
    box = layout.box()
    box.label(text="Platform Openings")
    box.prop(settings, "cut_platform_openings")
    if settings.cut_platform_openings:
        row = box.row(align=True)
        row.prop(settings, "opening_margin")
        row.prop(settings, "show_opening_cutters")
    box = layout.box()
    box.label(text="Debug")
    box.prop(settings, "show_clearance")


class SPCIRC_PT_panel(Panel):
    bl_label = "Circulation Generator"
    bl_idname = "SPCIRC_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Shantypunk"

    def draw(self, context):
        layout = self.layout
        host = selected_host(context)
        circulation = selected_circulation(context)
        if not host:
            layout.label(text="Select a Host Controller", icon='INFO')
            layout.label(text="or any object parented to one")
            return
        layout.label(
            text="Host: %s" % host.get("SP_INSTANCE_ID", host.name),
            icon='EMPTY_AXIS')
        if circulation:
            layout.label(
                text="Circulation: %s" % circulation.get("SP_INSTANCE_ID", circulation.name),
                icon='OUTLINER_OB_CURVE')
            draw_settings(layout, circulation.sp_circulation_settings)
            layout.operator("spcirc.update", icon='FILE_REFRESH')
            row = layout.row(align=True)
            row.operator("spcirc.validate", icon='CHECKMARK')
            row.operator("spcirc.delete", icon='TRASH')
        else:
            layout.label(text="New Circulation Defaults", icon='MOD_BUILD')
            draw_settings(layout, context.scene.sp_circulation_settings)
            layout.operator("spcirc.generate", icon='MOD_BUILD')


classes = (
    SPCIRC_OT_generate,
    SPCIRC_OT_update,
    SPCIRC_OT_validate,
    SPCIRC_OT_delete,
    SPCIRC_PT_panel,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
