import math

import bpy
from mathutils import Vector


MATERIALS = {
    "CONCRETE": (0.34, 0.36, 0.38, 1.0),
    "STEEL": (0.10, 0.14, 0.18, 1.0),
    "TIMBER": (0.34, 0.16, 0.055, 1.0),
    "ACCESS": (0.95, 0.34, 0.045, 1.0),
    "DEBUG_CLEARANCE": (1.0, 0.06, 0.02, 0.16),
}


def ensure_collection(name, parent=None):
    collection = bpy.data.collections.get(name) or bpy.data.collections.new(name)
    parent = parent or bpy.context.scene.collection
    if collection.name not in {child.name for child in parent.children}:
        parent.children.link(collection)
    return collection


def remove_collection(name):
    collection = bpy.data.collections.get(name)
    if not collection:
        return
    for child in list(collection.children):
        remove_collection(child.name)
    for obj in list(collection.objects):
        bpy.data.objects.remove(obj, do_unlink=True)
    bpy.data.collections.remove(collection)


def material(name):
    rgba = MATERIALS[name]
    data_name = "SPC_" + name
    mat = bpy.data.materials.get(data_name) or bpy.data.materials.new(data_name)
    mat.diffuse_color = rgba
    mat.use_nodes = True
    shader = mat.node_tree.nodes.get("Principled BSDF")
    if shader:
        shader.inputs["Base Color"].default_value = rgba
        shader.inputs["Roughness"].default_value = 0.70
        if "Alpha" in shader.inputs:
            shader.inputs["Alpha"].default_value = rgba[3]
    if rgba[3] < 1.0:
        try:
            mat.surface_render_method = 'DITHERED'
        except Exception:
            pass
    return mat


def move_to_collection(obj, collection):
    for owner in list(obj.users_collection):
        owner.objects.unlink(obj)
    collection.objects.link(obj)


def assign_material(obj, mat):
    if obj.data and hasattr(obj.data, "materials"):
        obj.data.materials.append(mat)


def join_objects(objects, name, collection):
    objects = [obj for obj in objects if obj and obj.name in bpy.data.objects]
    if not objects:
        return None
    if len(objects) == 1:
        objects[0].name = name
        return objects[0]
    bpy.ops.object.select_all(action='DESELECT')
    for obj in objects:
        obj.select_set(True)
    active = objects[0]
    bpy.context.view_layer.objects.active = active
    bpy.ops.object.join()
    active.name = name
    move_to_collection(active, collection)
    return active


def box(name, center, dimensions, collection, mat=None, angle=0.0, bevel=0.0):
    bpy.ops.mesh.primitive_cube_add(location=Vector(center), rotation=(0.0, 0.0, angle))
    obj = bpy.context.object
    obj.name = name
    obj.dimensions = Vector(dimensions)
    bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)
    move_to_collection(obj, collection)
    if mat:
        assign_material(obj, mat)
    if bevel:
        modifier = obj.modifiers.new("SPC_Edge_Soften", 'BEVEL')
        modifier.width = bevel
        modifier.segments = 2
        modifier.limit_method = 'ANGLE'
    return obj


def slab_between(name, start, end, width, thickness, collection, mat=None, bevel=0.0):
    start, end = Vector(start), Vector(end)
    delta = end - start
    horizontal = Vector((delta.x, delta.y, 0.0))
    length = horizontal.length
    if length < 1e-5:
        return box(name, start, (width, width, thickness), collection, mat, bevel=bevel)
    angle = math.atan2(horizontal.y, horizontal.x)
    center = (start + end) * 0.5
    center.z -= thickness * 0.5
    return box(name, center, (length, width, thickness), collection, mat, angle, bevel)


def beam_between(name, start, end, section, collection, mat=None):
    start, end = Vector(start), Vector(end)
    delta = end - start
    length = delta.length
    if length < 1e-5:
        return None
    bpy.ops.mesh.primitive_cube_add(location=(start + end) * 0.5)
    obj = bpy.context.object
    obj.name = name
    obj.dimensions = (length, section, section)
    obj.rotation_mode = 'QUATERNION'
    obj.rotation_quaternion = delta.to_track_quat('X', 'Z')
    bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)
    obj.rotation_mode = 'XYZ'
    move_to_collection(obj, collection)
    if mat:
        assign_material(obj, mat)
    return obj


def cylinder_between(name, start, end, radius, collection, mat=None, vertices=10):
    start, end = Vector(start), Vector(end)
    delta = end - start
    length = delta.length
    if length < 1e-5:
        return None
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices, radius=radius, depth=length, location=(start + end) * 0.5)
    obj = bpy.context.object
    obj.name = name
    obj.rotation_mode = 'QUATERNION'
    obj.rotation_quaternion = delta.to_track_quat('Z', 'Y')
    bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)
    obj.rotation_mode = 'XYZ'
    move_to_collection(obj, collection)
    if mat:
        assign_material(obj, mat)
    return obj


def empty(name, location, collection, display='ARROWS', size=0.30):
    obj = bpy.data.objects.new(name, None)
    collection.objects.link(obj)
    obj.location = Vector(location)
    obj.empty_display_type = display
    obj.empty_display_size = size
    obj.show_in_front = True
    obj.hide_render = True
    return obj


def clearance_between(name, start, end, width, height, collection, visible):
    start, end = Vector(start), Vector(end)
    lifted_start = start + Vector((0.0, 0.0, height * 0.5))
    lifted_end = end + Vector((0.0, 0.0, height * 0.5))
    obj = beam_between(name, lifted_start, lifted_end, max(width, height), collection,
                       material("DEBUG_CLEARANCE"))
    if obj:
        obj.display_type = 'WIRE'
        obj.show_in_front = True
        obj.hide_render = True
        obj.hide_viewport = not visible
        obj["SP_DEBUG_VOLUME"] = True
    return obj
