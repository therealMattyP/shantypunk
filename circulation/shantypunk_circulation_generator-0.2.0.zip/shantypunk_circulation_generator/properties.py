import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty, IntProperty, PointerProperty
from bpy.types import PropertyGroup


class SPCirculationSettings(PropertyGroup):
    seed: IntProperty(name="Seed", default=31, min=0, max=999999)
    route_width: FloatProperty(name="Route Width", default=1.10, min=0.65, max=3.0, unit='LENGTH')
    stair_width: FloatProperty(name="Stair Width", default=1.10, min=0.65, max=3.0, unit='LENGTH')
    target_riser: FloatProperty(name="Target Riser", default=0.18, min=0.10, max=0.25, unit='LENGTH')
    tread_depth: FloatProperty(name="Tread Depth", default=0.28, min=0.20, max=0.50, unit='LENGTH')
    landing_depth: FloatProperty(name="Landing Depth", default=1.30, min=0.75, max=4.0, unit='LENGTH')
    platform_thickness: FloatProperty(name="Platform Thickness", default=0.16, min=0.06, max=0.50, unit='LENGTH')
    headroom: FloatProperty(name="Protected Headroom", default=2.15, min=1.90, max=4.0, unit='LENGTH')
    rail_height: FloatProperty(name="Guardrail Height", default=1.05, min=0.75, max=1.50, unit='LENGTH')
    rail_spacing: FloatProperty(name="Guardrail Post Spacing", default=1.40, min=0.50, max=3.0, unit='LENGTH')
    stair_material: EnumProperty(name="Primary Construction", items=[
        ('AUTO', "Automatic", "Choose construction from the host archetype"),
        ('CONCRETE', "Concrete", "Solid concrete steps and platforms"),
        ('STEEL', "Steel", "Framed steel stairs and platforms"),
        ('TIMBER', "Timber", "Framed timber stairs and platforms"),
    ], default='AUTO')
    vertical_fallback: EnumProperty(name="Vertical Fallback", items=[
        ('SWITCHBACK', "Switchback Stair", "Use alternating stair flights when anchors align vertically"),
        ('LADDER', "Ladder", "Use a ladder for vertically aligned secondary connections"),
    ], default='SWITCHBACK')
    railing_mode: EnumProperty(name="Railing Placement", items=[
        ('AUTO', "Exposed Edges", "Rail stairs and unsupported route edges only"),
        ('ALL', "Both Sides", "Rail both sides of every eligible route"),
        ('NONE', "No Railings", "Do not generate guardrails"),
    ], default='AUTO')
    generate_guardrails: BoolProperty(name="Generate Guardrails", default=True)
    cut_platform_openings: BoolProperty(name="Cut Platform Openings", default=True)
    opening_margin: FloatProperty(name="Opening Margin", default=0.12, min=0.02, max=0.60, unit='LENGTH')
    show_opening_cutters: BoolProperty(name="Show Opening Cutters", default=False)
    connect_cell_zones: BoolProperty(name="Connect Building Zones", default=True)
    expose_bridge_ports: BoolProperty(name="Expose Bridge Ports", default=True)
    show_clearance: BoolProperty(name="Show Clearance Volumes", default=False)


SETTING_FIELDS = (
    "seed", "route_width", "stair_width", "target_riser", "tread_depth",
    "landing_depth", "platform_thickness", "headroom", "rail_height",
    "rail_spacing", "stair_material", "vertical_fallback",
    "railing_mode", "generate_guardrails", "cut_platform_openings",
    "opening_margin", "show_opening_cutters", "connect_cell_zones",
    "expose_bridge_ports", "show_clearance",
)


def copy_settings(source, destination):
    for name in SETTING_FIELDS:
        setattr(destination, name, getattr(source, name))


classes = (SPCirculationSettings,)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.sp_circulation_settings = PointerProperty(type=SPCirculationSettings)
    bpy.types.Object.sp_circulation_settings = PointerProperty(type=SPCirculationSettings)


def unregister():
    del bpy.types.Object.sp_circulation_settings
    del bpy.types.Scene.sp_circulation_settings
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
