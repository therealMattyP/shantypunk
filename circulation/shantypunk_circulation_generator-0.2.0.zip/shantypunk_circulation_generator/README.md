# Shantypunk Circulation Generator v0.2

Generates editable, validated circulation from a Shantypunk Host Generator instance. The solver contract is intentionally generic so future growth/layout systems can supply the same entries, levels, destinations, supports, obstacles, and attachment points without a formal host.

## Generated systems

- Primary bottom-to-top route
- Concrete, steel, or timber stairs selected automatically from the host archetype
- Optional ladder fallback for vertically aligned anchors
- Landings, connectors, access branches, and support-aware guardrails
- Non-destructive stair and ladder openings on eligible host platforms
- Explicit no-rail edges at building entrances and future bridge connections
- Consolidated stair, ladder, and guardrail assemblies for lighter scenes
- Building-access nodes for every reachable `CELL_ATTACH` socket
- Reserved bridge ports for `BRIDGE_ATTACH` sockets
- Protected headroom visualization
- Host-local access, exclusion, opening, apron, and bridge contracts for builders
- Reachability graph, versioned JSON manifest, and validation report

## Controllers and updating

Select a Host Controller—or any child of it—and use **Shantypunk > Circulation Generator > Generate Circulation**. The generated Circulation Controller is parented to the Host Controller, so the entire system follows host movement, rotation, and scale.

Select the Circulation Controller, any circulation component, the Host Controller, or one of its children to edit the saved settings. Use **Update Circulation** after changing settings or regenerating the source host.

## Builder contract

The v0.2 manifest exposes host-local `access_contracts`, `exclusions`, `opening_reservations`, `no_rail_edges`, and `bridge_reservations`. These records let the Building Generator subtract protected circulation and access space before accepting a cell. Opening cutters remain editable and are removed cleanly when circulation is updated or deleted.

## Install

Install the ZIP from Blender's **Edit > Preferences > Add-ons > Install from Disk**. Install and enable Shantypunk Host Generator 0.2 or later before generating host-bound circulation.

Primary target: Blender 5.1. Tested compatibility targets: Blender 4.5 LTS and Blender 5.2.
