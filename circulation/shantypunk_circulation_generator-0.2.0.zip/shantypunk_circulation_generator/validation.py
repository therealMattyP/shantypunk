import bpy

from . import metadata


def _source_signature(host_controller):
    from .solver import source_signature
    return source_signature(host_controller)


def validate(controller, host_controller, manifest):
    issues = []
    if not controller or controller.get("SP_ROLE") != "CIRCULATION_CONTROLLER":
        issues.append({"severity": "ERROR", "code": "NO_CIRCULATION_CONTROLLER"})
    if not host_controller or host_controller.get("SP_ROLE") != "HOST_CONTROLLER":
        issues.append({"severity": "ERROR", "code": "NO_SOURCE_HOST"})
    collection = bpy.data.collections.get(controller.get("SP_INSTANCE_COLLECTION", "")) if controller else None
    objects = list(collection.all_objects) if collection else []
    if not collection:
        issues.append({"severity": "ERROR", "code": "NO_INSTANCE_COLLECTION"})
    ids = {}
    for obj in objects:
        stable_id = obj.get("SP_ID")
        if not stable_id:
            issues.append({"severity": "ERROR", "code": "MISSING_ID", "object": obj.name})
            continue
        ids.setdefault(stable_id, []).append(obj.name)
        if obj != controller and obj.parent != controller:
            issues.append({"severity": "ERROR", "code": "WRONG_PARENT", "object": obj.name})
        if obj.get("SP_ROLE") != "CIRCULATION_CONTROLLER":
            if any(abs(value - 1.0) > 1e-5 for value in obj.scale):
                issues.append({"severity": "ERROR", "code": "UNAPPLIED_SCALE", "object": obj.name})
            if any(abs(value) > 1e-5 for value in obj.rotation_euler):
                issues.append({"severity": "ERROR", "code": "UNAPPLIED_ROTATION", "object": obj.name})
    for stable_id, names in ids.items():
        if len(names) > 1:
            issues.append({
                "severity": "ERROR", "code": "DUPLICATE_ID",
                "details": {"id": stable_id, "objects": names},
            })
    nodes = {node["id"]: node for node in manifest.get("nodes", [])}
    entries = [node for node in nodes.values() if node.get("type") == "GROUND_ENTRY"]
    if len(entries) != 1:
        issues.append({"severity": "ERROR", "code": "GROUND_ENTRY_COUNT", "details": len(entries)})
    reachable = {entries[0]["id"]} if entries else set()
    changed = True
    while changed:
        changed = False
        for edge in manifest.get("edges", []):
            if edge["from"] in reachable and edge["to"] not in reachable:
                reachable.add(edge["to"])
                changed = True
    for node_id in nodes:
        if node_id not in reachable:
            issues.append({"severity": "ERROR", "code": "UNREACHABLE_NODE", "details": node_id})
    contracts = manifest.get("contracts", {})
    for segment in manifest.get("segments", []):
        if segment.get("type") == "STAIR":
            if segment.get("riser", 0.0) > 0.25:
                issues.append({"severity": "ERROR", "code": "RISER_TOO_HIGH", "details": segment})
            if segment.get("tread", 0.0) < 0.20:
                issues.append({"severity": "ERROR", "code": "TREAD_TOO_SHALLOW", "details": segment})
    if contracts.get("route_width", 0.0) < 0.65:
        issues.append({"severity": "ERROR", "code": "ROUTE_TOO_NARROW"})
    access_nodes = [node for node in nodes.values() if node.get("type") == "BUILDING_ACCESS"]
    access_contracts = manifest.get("access_contracts", [])
    if len(access_nodes) != len(access_contracts):
        issues.append({
            "severity": "ERROR", "code": "ACCESS_CONTRACT_COUNT_MISMATCH",
            "details": {"nodes": len(access_nodes), "contracts": len(access_contracts)},
        })
    required_access = {
        "source_socket", "node_id", "location", "entrance_direction",
        "outward_direction", "frontage_width", "apron_depth", "build_side",
    }
    for contract in access_contracts:
        missing = sorted(required_access - set(contract))
        if missing:
            issues.append({
                "severity": "ERROR", "code": "INCOMPLETE_ACCESS_CONTRACT",
                "details": {"node": contract.get("node_id"), "missing": missing},
            })
    host_ids = {obj.get("SP_ID", obj.name) for obj in host_controller.children} if host_controller else set()
    for opening in manifest.get("opening_reservations", []):
        for target in opening.get("targets", []):
            if target not in host_ids:
                issues.append({
                    "severity": "ERROR", "code": "OPENING_TARGET_MISSING",
                    "details": {"opening": opening.get("id"), "target": target},
                })
    if contracts.get("contract_version", 0) < 2:
        issues.append({"severity": "ERROR", "code": "OUTDATED_PUBLIC_CONTRACT"})
    if host_controller and manifest.get("source_signature") != _source_signature(host_controller):
        issues.append({
            "severity": "WARNING", "code": "SOURCE_HOST_CHANGED",
            "details": "Update circulation to match the current host sockets",
        })
    summary = {
        severity: sum(1 for item in issues if item["severity"] == severity)
        for severity in ("ERROR", "WARNING", "INFO")
    }
    return {"summary": summary, "issues": issues}


def write_report(report, text_name=metadata.VALIDATION_TEXT):
    lines = ["SHANTYPUNK CIRCULATION GENERATOR VALIDATION", "=" * 64]
    lines.extend("%s: %d" % (name, count) for name, count in report["summary"].items())
    lines.append("")
    for item in report["issues"]:
        lines.append("%s %s %s" % (
            item["severity"], item["code"], item.get("object", item.get("details", ""))))
    text = bpy.data.texts.get(text_name) or bpy.data.texts.new(text_name)
    text.clear()
    text.write("\n".join(lines))
    return lines
